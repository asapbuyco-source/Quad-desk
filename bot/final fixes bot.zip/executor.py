import asyncio
import logging
import os
import time
from typing import Dict, Any, Optional
import ccxt.async_support as ccxt
from bot import heartbeat
from bot.notifier import TelegramNotifier

logger = logging.getLogger(__name__)

MAX_SHORT_EXPOSURE_BTC = 0.008
MAX_REQUEUE_ATTEMPTS = 3  # H4 FIX: retry failed TP placements up to N times before giving up


class TradingExecutor:
    """
    Handles risk-managed execution of trading signals via ccxt.

    Supports Coinbase Advanced Trade (spot) and Binance (legacy).
    In DRY_RUN mode the executor logs what it WOULD do without placing
    any real orders — safe for live observation/testing.

    Coinbase Advanced Trade uses RSA/EC private key authentication.
    Set COINBASE_API_KEY_NAME and COINBASE_PRIVATE_KEY in your .env.
    """

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        testnet: bool = True,
        dry_run: bool = True,
        exchange_id: str = "binance",
        coinbase_key_name: str = "",
        coinbase_private_key: str = "",
        tg_token: str = "",
        tg_chat_id: str = "",
    ):
        self.testnet   = testnet
        self.exchange_id = exchange_id.lower()
        self.is_futures  = "binanceusdm" in self.exchange_id or "future" in self.exchange_id
        self.dry_run   = dry_run or not self._has_credentials(
            exchange_id, api_key, api_secret, coinbase_key_name, coinbase_private_key
        )
        
        self.notifier = TelegramNotifier(tg_token, tg_chat_id)

        if self.dry_run:
            logger.warning("[Executor] DRY-RUN mode: no real orders will be placed.")

        # ── Exchange initialisation ───────────────────────────────────────
        if self.exchange_id == "coinbase":
            self.exchange = self._init_coinbase(
                coinbase_key_name, coinbase_private_key
            )
        else:
            # Binance (legacy / fallback)
            self.exchange = self._init_binance(api_key, api_secret, testnet, self.exchange_id)

        self.active_position: Optional[Dict[str, Any]] = None
        self.pending_order: Optional[Dict[str, Any]] = None  # Track unfilled orders
        self.lock_expiry: float = 0.0
        self.last_panic_reason: str = ""
        self.failed_order_ts: float = 0.0  # Cooldown after live order failure (prevents -2015 spam)
        self._live_exit_last_poll_ts: float = 0.0
        self._live_exit_poll_interval_s: float = 20.0
        self._live_exit_backoff_until: float = 0.0
        self._live_exit_backoff_s: float = 30.0
        self._live_exit_last_error_log: float = 0.0
        # P0-3 FIX: Dedicated flag set when emergency_flatten fails.
        # A boolean survives the heartbeat poll clearing active_position; a sentinel dict does not.
        self._flatten_failed: bool = False
        # P0-1 FIX: Lock to prevent TOCTOU race between heartbeat poll and main loop
        # both reading/writing active_position in overlapping async yield points.
        # C2+C5+C6 FIX: Semaphore(1) instead of Lock — reentrant so nested calls
        # (e.g. check_position_exit → _check_live_position_exit) don't deadlock.
        import asyncio as _asyncio_for_lock
        self._position_lock = _asyncio_for_lock.Semaphore(1)

        # PHASE-0.3: Exchange-specific fee table.
        # Fees were hardcoded as Binance USDM rates in 3 separate places.
        # Coinbase charges up to 1.2% taker — 24× higher than the old assumption.
        _EXCHANGE_FEES = {
            "coinbase":    {"taker": 0.012,  "maker": 0.006},
            "binance":     {"taker": 0.001,  "maker": 0.0002},
            "binanceusdm": {"taker": 0.0005, "maker": 0.0002},
            "kraken":      {"taker": 0.0026, "maker": 0.0016},
            "okx":         {"taker": 0.001,  "maker": 0.0008},
        }
        _fees = _EXCHANGE_FEES.get(self.exchange_id, {"taker": 0.001, "maker": 0.0002})
        self.TAKER_FEE = _fees["taker"]
        self.MAKER_FEE = _fees["maker"]
        logger.info(f"[Executor] Fee rates for {self.exchange_id}: taker={self.TAKER_FEE:.4%} maker={self.MAKER_FEE:.4%}")

    def _extract_trade_fee(self, trade: dict) -> float:
        """Best-effort fee extraction from ccxt-normalized and raw exchange trade payloads."""
        if not trade:
            return 0.0
        total = 0.0
        fee = trade.get("fee") or {}
        if isinstance(fee, dict):
            try:
                total += abs(float(fee.get("cost") or 0.0))
            except (TypeError, ValueError):
                pass
        fees = trade.get("fees") or []
        if isinstance(fees, list):
            for item in fees:
                if isinstance(item, dict):
                    try:
                        total += abs(float(item.get("cost") or 0.0))
                    except (TypeError, ValueError):
                        pass
        info = trade.get("info") or {}
        for key in ("commission", "fee", "realizedCommission"):
            try:
                total += abs(float(info.get(key) or 0.0))
            except (TypeError, ValueError):
                pass
        return total

    @staticmethod
    def _float_or_zero(value) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0

    def _extract_trade_amount(self, trade: dict) -> float:
        """Best-effort filled amount extraction from ccxt-normalized/raw trades."""
        if not trade:
            return 0.0
        for key in ("amount", "qty", "filled"):
            amount = self._float_or_zero(trade.get(key))
            if amount > 0.0:
                return abs(amount)
        info = trade.get("info") or {}
        for key in ("qty", "lastQty", "executedQty", "amount"):
            amount = self._float_or_zero(info.get(key))
            if amount > 0.0:
                return abs(amount)
        return 0.0

    def _extract_trade_price(self, trade: dict) -> float:
        if not trade:
            return 0.0
        for key in ("price", "average"):
            price = self._float_or_zero(trade.get(key))
            if price > 0.0:
                return price
        info = trade.get("info") or {}
        for key in ("price", "avgPrice"):
            price = self._float_or_zero(info.get(key))
            if price > 0.0:
                return price
        return 0.0

    def _extract_trade_realized_pnl(self, trade: dict) -> float:
        info = (trade or {}).get("info") or {}
        for key in ("realizedPnl", "realizedProfit", "rp"):
            value = self._float_or_zero(info.get(key))
            if value != 0.0:
                return value
        return 0.0

    def _trade_timestamp_ms(self, trade: dict) -> float:
        info = (trade or {}).get("info") or {}
        trade = trade or {}
        for value in (trade.get("timestamp"), info.get("time"), info.get("T"), info.get("transactTime")):
            ts = self._float_or_zero(value)
            if ts > 0.0:
                return ts * 1000.0 if ts < 10_000_000_000 else ts
        return 0.0

    def _aggregate_closing_trades(self, trades: list, close_side: str, pos: dict) -> dict | None:
        """Aggregate the latest closing fills for the current remaining position.

        Binance can split one SL/TP close into several trade fills. Accounting only
        the last fill understates losses/wins and distorts cooldowns. We walk trades
        newest-first until the current remaining size is covered, which also avoids
        double-counting earlier partial-profit closes.
        """
        entry_ts = self._float_or_zero(pos.get("entry_ts"))
        target_size = abs(self._float_or_zero(pos.get("size") or pos.get("qty")))
        candidates = [
            trade for trade in (trades or [])
            if self._is_probable_closing_trade(trade, close_side, entry_ts)
        ]
        if not candidates:
            return None

        indexed = list(enumerate(candidates))
        indexed.sort(
            key=lambda item: (self._trade_timestamp_ms(item[1]), item[0]),
            reverse=True,
        )

        selected_reversed = []
        selected_amount = 0.0
        tolerance = max(target_size * 0.001, 1e-12)
        for _, trade in indexed:
            selected_reversed.append(trade)
            amount = self._extract_trade_amount(trade)
            if amount > 0.0:
                selected_amount += amount
            if target_size > 0.0 and selected_amount >= target_size - tolerance:
                break

        if target_size > 0.0 and selected_amount <= 0.0:
            selected_reversed = [indexed[0][1]]

        selected = list(reversed(selected_reversed))
        total_amount = 0.0
        total_quote = 0.0
        gross_pnl = 0.0
        close_fee = 0.0
        has_exchange_pnl = False
        last_price = 0.0

        for trade in selected:
            amount = self._extract_trade_amount(trade)
            price = self._extract_trade_price(trade)
            pnl = self._extract_trade_realized_pnl(trade)
            fee = self._extract_trade_fee(trade)

            if price > 0.0:
                last_price = price
            if amount > 0.0 and price > 0.0:
                total_amount += amount
                total_quote += amount * price
            if pnl != 0.0:
                has_exchange_pnl = True
            gross_pnl += pnl
            close_fee += fee

        fill_price = (total_quote / total_amount) if total_amount > 0.0 else last_price
        if fill_price <= 0.0:
            return None

        if not has_exchange_pnl:
            effective_size = total_amount if total_amount > 0.0 else target_size
            entry = self._float_or_zero(pos.get("entry_price")) or fill_price
            side = str(pos.get("side") or "buy").lower()
            gross_pnl = (
                (fill_price - entry) * effective_size
                if side == "buy"
                else (entry - fill_price) * effective_size
            )

        return {
            "fill_price": fill_price,
            "gross_pnl": gross_pnl,
            "close_fee": close_fee,
            "amount": total_amount,
            "trade_count": len(selected),
            "has_exchange_pnl": has_exchange_pnl,
        }

    def _net_exchange_realized_pnl(
        self,
        gross_pnl: float,
        pos: dict,
        exit_price: float,
        closing_trade: dict | None = None,
        closing_fee: float | None = None,
    ) -> tuple[float, float]:
        """Convert exchange realizedPnl to account-impact PnL by subtracting commissions.

        Binance futures reports realizedPnl separately from commissions. Without this
        adjustment, tiny fee-negative exits look like wins and distort cooldowns,
        calibration, and daily PnL.
        """
        entry = float(pos.get("entry_price") or exit_price or 0.0)
        size = float(pos.get("size") or 0.0)
        entry_fee = float(
            pos.get("entry_fee")
            or pos.get("entry_fee_est")
            or abs(entry * size * self.TAKER_FEE)
        )
        close_fee = float(closing_fee) if closing_fee is not None else self._extract_trade_fee(closing_trade or {})
        if close_fee <= 0.0:
            close_fee = abs(float(exit_price or entry) * size * self.TAKER_FEE)
        total_fees = entry_fee + close_fee
        return float(gross_pnl) - total_fees, total_fees

    @staticmethod
    def _is_probable_closing_trade(trade: dict, close_side: str, entry_ts: float = 0.0) -> bool:
        trade_side = str(trade.get("side") or "").lower()
        if trade_side and trade_side != close_side.lower():
            return False
        trade_ts = trade.get("timestamp") or (trade.get("info") or {}).get("time")
        if trade_ts and entry_ts:
            try:
                trade_ts_f = float(trade_ts)
                if trade_ts_f < 10_000_000_000:
                    trade_ts_f *= 1000.0
                if trade_ts_f < (float(entry_ts) * 1000.0) - 5_000.0:
                    return False
            except (TypeError, ValueError):
                pass
        return True

    @staticmethod
    def _classify_live_exit_type(pos: dict, fill_price: float) -> str:
        """Classify a live flat position from fill geometry, not realized PnL sign."""
        side = str((pos or {}).get("side") or "buy").lower()
        entry = TradingExecutor._float_or_zero((pos or {}).get("entry_price"))
        stop_loss = TradingExecutor._float_or_zero((pos or {}).get("stop_loss"))
        take_profit = TradingExecutor._float_or_zero((pos or {}).get("take_profit"))
        fill = TradingExecutor._float_or_zero(fill_price)
        if fill <= 0.0:
            return "MANUAL"

        risk_dist = TradingExecutor._float_or_zero((pos or {}).get("initial_risk_dist"))
        if risk_dist <= 0.0 and entry > 0.0 and stop_loss > 0.0:
            risk_dist = abs(entry - stop_loss)
        tolerance = max(abs(fill) * 0.0005, risk_dist * 0.10, 1e-9)

        if side == "buy":
            if stop_loss > 0.0 and fill <= stop_loss + tolerance:
                return "SL"
            if take_profit > 0.0 and fill >= take_profit - tolerance:
                return "TP"
        else:
            if stop_loss > 0.0 and fill >= stop_loss - tolerance:
                return "SL"
            if take_profit > 0.0 and fill <= take_profit + tolerance:
                return "TP"
        return "MANUAL"

    # ------------------------------------------------------------------
    # Static helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _has_credentials(exchange_id, api_key, api_secret, cb_name, cb_key) -> bool:
        if exchange_id.lower() == "coinbase":
            return bool(cb_name and cb_key)
        return bool(api_key and api_secret)

    @staticmethod
    def _init_coinbase(key_name: str, private_key: str) -> ccxt.Exchange:
        """
        Coinbase Advanced Trade uses EC/RSA private keys, not HMAC secrets.
        ccxt maps: apiKey → key_name, secret → private_key (PEM string).
        The private key may be stored with literal \\n — normalise to real newlines.
        """
        # Normalise escaped newlines from env vars
        normalised_key = private_key.replace("\\n", "\n").strip()

        exchange = ccxt.coinbase({
            "apiKey":          key_name,
            "secret":          normalised_key,
            "enableRateLimit": True,
            "options": {
                "defaultType":     "spot",
                # Hard-veto legacy V2 features that crash CDP keys
                "fetchCurrencies": False,
                "fetchMarkets":    True,  # Still need markets
            },
        })
        # Override the has['fetchCurrencies'] to force CCXT to skip the public currency fetch
        exchange.has['fetchCurrencies'] = False
        
        logger.info("[Executor] Coinbase Advanced Trade (V3) initialised.")
        return exchange

    @staticmethod
    def _init_binance(api_key: str, api_secret: str, testnet: bool, exchange_id: str = "binance") -> ccxt.Exchange:
        # ── Key Format Check (Ed25519 vs HMAC) ──────────────────────────
        # If the secret contains BEGIN header, it's an Ed25519/RSA key.
        is_ed25519 = str(api_secret).strip().startswith("-----BEGIN")
        logger.info(f"[Executor] Initialising Binance ({'Ed25519' if is_ed25519 else 'HMAC'})")

        # Determine if we should force Futures mode
        is_futures_id = "usdm" in exchange_id.lower() or "future" in exchange_id.lower()
        
        # [FIX] Use specialized ccxt.binanceusdm if targeting USDM futures.
        # This prevents CCXT's load_markets from hitting Spot/Margin SAPI endpoints
        # which can trigger -2015 errors on Futures-only API keys.
        exchange_class = ccxt.binanceusdm if is_futures_id else ccxt.binance
        
        exchange = exchange_class({
            "apiKey":          api_key,
            "secret":          api_secret,
            "enableRateLimit": True,
            "options": {
                "defaultType": "future" if (is_futures_id or testnet) else "spot",
                "adjustForTimeDifference": True,
                "recvWindow": 10000,
            },
        })
        
        if testnet:
            exchange.set_sandbox_mode(True)
        
        if not hasattr(exchange, "options") or exchange.options is None:
            exchange.options = {}

        # Prevent CCXT from trying to load margin info during load_markets
        exchange.has['fetchMarginAllPairs'] = False
        exchange.has['fetchFundingHistory'] = False
        exchange.has['fetchCurrencies'] = False
        
        active_type = exchange.options.get("defaultType", "spot")
        exchange_name = getattr(exchange_class, "__name__", type(exchange).__name__)
        logger.info(f"[Executor] Binance ({'testnet' if testnet else 'live'}) initialised as {active_type.upper()} via {exchange_name}.")
        return exchange

    # ------------------------------------------------------------------
    # Symbol translation helpers
    # ------------------------------------------------------------------
    def _get_ccxt_symbol(self, raw_symbol: str) -> str:
        """
        Convert a raw symbol (e.g. BTCUSDT) to ccxt unified format.
        Binance USDM futures : BTCUSDT  → BTC/USDT:USDT
        Spot / other         : BTCUSDT  → BTC/USDT
        Called by main.py to set futures leverage at startup.
        """
        symbol = raw_symbol.strip().upper()

        # Already unified (contains /)
        if "/" in symbol:
            if self.is_futures and ":" not in symbol:
                quote = symbol.split("/")[-1]
                return f"{symbol}:{quote}"
            return symbol

        # Dash format (BTC-USDT)
        if "-" in symbol:
            symbol = symbol.replace("-", "/")
            if self.is_futures and ":" not in symbol:
                quote = symbol.split("/")[-1]
                return f"{symbol}:{quote}"
            return symbol

        # Raw concatenated form (BTCUSDT, ETHUSDT, …)
        for quote in ("USDT", "USDC", "BUSD", "USD", "BTC", "ETH", "BNB"):
            if symbol.endswith(quote):
                base    = symbol[: -len(quote)]
                unified = f"{base}/{quote}"
                if self.is_futures:
                    return f"{unified}:{quote}"
                return unified

        # Fallback — return as-is
        return symbol

    def _to_exchange_symbol(self, symbol: str) -> str:
        """
        Translate a symbol to the exchange's native format for CCXT.
        Coinbase uses BTC/USD (ccxt unified) or BTC-USD (raw API).
        This method converts any format to ccxt unified: BTC/USDC
        """
        if self.exchange_id != "coinbase":
            return symbol

        # Normalize: ensure we return ccxt unified format (BTC/USDC, BTC/USD, etc.)
        symbol = symbol.strip().upper()
        
        # If already in BTC/USDC format, return as-is
        if "/" in symbol:
            return symbol
        
        # If in BTC-USDC format, convert to BTC/USDC
        if "-" in symbol:
            return symbol.replace("-", "/")

        # BTCUSDT style → BTC/USDT
        # Common quote currencies in order of descending length (avoid partial match)
        for quote in ("USDT", "USDC", "USD", "BTC", "ETH", "BNB"):
            if symbol.endswith(quote):
                base = symbol[: -len(quote)]
                return f"{base}/{quote}"
        
        # Fallback — return with / added if possible
        return symbol

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    async def initialize(self):
        """Load markets and confirm connectivity.

        Binance USDM 'markets not loaded' fix:
        - Retries load_markets() up to 3× with back-off on transient network errors.
        - If all retries fail, injects a minimal BTC/USDT:USDT futures market spec so
          amount_to_precision / price_to_precision calls don't crash on the next order.
        """
        if self.dry_run and not self.exchange.apiKey:
            logger.info("[Executor] Skipping market load in keyless dry-run mode.")
            return

        env  = "TESTNET" if self.testnet else "LIVE"
        exch = self.exchange_id.upper()

        # --- Retry loop: up to 3 attempts with exponential back-off ---
        last_exc: Optional[Exception] = None
        for attempt in range(3):
            try:
                await self.exchange.load_markets()
                logger.info(f"[Executor] Connected to {exch} {env} ✓ (attempt {attempt + 1})")
                
                # --- Boot Position Check (no reconciliation) ---
                # If an open position exists on the exchange, alert via Telegram
                # and continue trading normally. We do NOT reconcile because the
                # SL/TP would be guessed from an ATR proxy and could be dangerously wrong.
                # User commits to closing all trades before starting the bot.
                try:
                    positions = await self.exchange.fetch_positions()
                    open_found = False
                    for pos in positions:
                        qty = float(pos.get("contracts", 0) or pos.get("positionAmt", 0))
                        if abs(qty) > 0.0001:
                            open_found = True
                            side = "buy" if qty > 0 else "sell"
                            entry_p = float(pos.get("entryPrice", 0))
                            warn_msg = (
                                f"⚠️ Quad-Desk BOOT WARNING\n"
                                f"Open position found: {side.upper()} {abs(qty)} {pos.get('symbol')} @ {entry_p:.2f}\n"
                                f"Bot is starting normally but has NO internal SL/TP for this position.\n"
                                f"Please verify on Binance — this position is NOT tracked by the bot."
                            )
                            logger.warning(f"[Executor] {warn_msg}")
                            if self.notifier:
                                await self.notifier.send_message(warn_msg)
                    if open_found and not self.dry_run:
                        import os as _os
                        policy = _os.environ.get("BOT_BOOT_OPEN_POSITION_POLICY", "halt").strip().lower()
                        if policy == "halt":
                            msg = (
                                "[Executor] Open exchange position found on boot. "
                                "Live entries blocked by BOT_BOOT_OPEN_POSITION_POLICY=halt. "
                                "Close the position manually or restart with policy=warn/rehydrate."
                            )
                            logger.critical(msg)
                            if self.notifier:
                                await self.notifier.send_error_alert(msg)
                            raise RuntimeError(msg)
                    if not open_found:
                        logger.info("[Executor] Boot clean — no open positions found on exchange.")

                except Exception as e:
                    if "BOT_BOOT_OPEN_POSITION_POLICY=halt" in str(e):
                        raise
                    logger.warning(f"[Executor] Could not check positions on boot: {e}")

                # Send startup status notification
                try:
                    mode = "DRY-RUN 🔵" if self.dry_run else "LIVE 🟢"
                    await self.notifier.send_message(
                        f"🤖 Quad-Desk {mode} STARTED\n"
                        f"Exchange: {self.exchange_id.upper()} | "
                        f"Taker fee: {self.TAKER_FEE:.3%}"
                    )
                except Exception:
                    pass

                return   # success — exit initialize
            except Exception as e:
                last_exc = e
                wait_s   = 2 ** attempt          # 1s, 2s, 4s
                logger.warning(
                    f"[Executor] load_markets attempt {attempt + 1}/3 failed: {e}. "
                    f"{'Retrying in ' + str(wait_s) + 's…' if attempt < 2 else 'All retries exhausted.'}"
                )
                if attempt < 2:
                    import asyncio as _asyncio
                    await _asyncio.sleep(wait_s)

        # All retries failed — inject minimal market fallback to prevent order failures
        logger.warning(
            f"[Executor] Could not load {exch} markets after 3 attempts ({last_exc}). "
            "Injecting minimal market fallback — bot will attempt to continue."
        )
        if not self.dry_run:
            msg = (
                f"[Executor] Could not load {exch} markets after 3 attempts ({last_exc}). "
                "Live trading blocked because exchange precision/limits are unavailable."
            )
            logger.critical(msg)
            if self.notifier:
                try:
                    await self.notifier.send_error_alert(msg)
                except Exception:
                    pass
            raise RuntimeError(msg)

        self._inject_fallback_markets()

    def _inject_fallback_markets(self):
        """Injects minimal market data into CCXT to prevent crashes on market load failure.
        Dynamically handles the active BOT_SYMBOL so ETH, SOL, etc. are supported.
        """
        import os as _os
        if not hasattr(self.exchange, 'markets') or self.exchange.markets is None:
            self.exchange.markets = {}
        if not hasattr(self.exchange, 'symbols') or self.exchange.symbols is None:
            self.exchange.symbols = []

        # Determine the active symbol from env (set by launcher per-process)
        raw_sym = _os.environ.get("BOT_SYMBOL", "BTC/USDT")
        ccxt_sym = self._get_ccxt_symbol(raw_sym)  # e.g. ETH/USDT:USDT

        if self.exchange_id == "coinbase":
            # Coinbase: inject the active symbol as a spot market
            base  = raw_sym.split("/")[0].upper()
            quote = raw_sym.split("/")[-1].upper() if "/" in raw_sym else "USD"
            cb_sym = f"{base}/{quote}"
            self.exchange.markets[cb_sym] = {
                'id': f'{base}-{quote}', 'symbol': cb_sym, 'base': base, 'quote': quote,
                'precision': {'amount': 0.00000001, 'price': 0.01},
                'limits': {'amount': {'min': 0.00001, 'max': 10000}, 'price': {'min': 0.01, 'max': 1000000}, 'cost': {'min': 1.0}},
                'active': True, 'type': 'spot', 'spot': True, 'margin': False, 'contract': False
            }
            if cb_sym not in self.exchange.symbols:
                self.exchange.symbols.append(cb_sym)
            logger.warning(f"[Executor] Fallback market injected for Coinbase: {cb_sym}")

        elif self.is_futures:
            # Binance USDM: inject the active symbol as a futures market
            # Derive precision from known symbols; default to 3dp amount / 2dp price
            _AMOUNT_PREC = {"BTC": 0.001, "ETH": 0.001, "SOL": 0.1,
                             "AVAX": 0.1, "BNB": 0.01, "DOGE": 1.0, "PEPE": 1.0}
            base = raw_sym.split("/")[0].upper()
            amt_prec = _AMOUNT_PREC.get(base, 0.01)
            self.exchange.markets[ccxt_sym] = {
                'id':        raw_sym.replace("/", "").replace(":", "").upper().split("USDT")[0] + "USDT",
                'symbol':    ccxt_sym,
                'base':      base,
                'quote':     'USDT',
                'settle':    'USDT',
                'precision': {'amount': amt_prec, 'price': 0.01},
                'limits':    {'amount': {'min': amt_prec, 'max': 100000}, 'price': {'min': 0.01, 'max': 1000000}},
                'active': True, 'type': 'future', 'spot': False, 'margin': False, 'contract': True
            }
            if ccxt_sym not in self.exchange.symbols:
                self.exchange.symbols.append(ccxt_sym)
            logger.warning(f"[Executor] Fallback market injected for Binance USDM: {ccxt_sym}")

    async def close(self):
        await self.exchange.close()

    # ------------------------------------------------------------------
    # Firestore trade logger
    # ------------------------------------------------------------------
    def _log_trade(self, symbol: str, side: str, verdict: str,
                   entry: float, stop_loss: float, take_profit: float,
                   ulis_verdict: str = "",
                   metrics: dict = None,
                   signal: dict = None,
                   size: float = 0.0):
        """Write a trade record to Firestore `botTrades` collection.
        
        5.6: Includes full signal attribution chain so post-trade analysis can
        identify which signals (regime, OFI, Z-score, RSI, Bayesian confidence)
        drove each entry decision.
        """
        db = heartbeat.get_db()
        if db is None:
            return
        try:
            from firebase_admin import firestore as fs
            m = metrics or {}
            s = signal or {}
            doc = {
                "symbol":         symbol,
                "side":           side,
                "verdict":        verdict,
                "entry_price":    entry,
                "size":           float(size or 0.0),
                "stop_loss":      stop_loss,
                "take_profit":    take_profit,
                "timestamp":      fs.SERVER_TIMESTAMP,
                "mode":           "DRY-RUN" if self.dry_run else "LIVE",
                "status":         "OPEN",
                "portfolio_side": "long" if side == "buy" else "short",
                "exchange":       self.exchange_id,
                "ulis_verdict":   ulis_verdict,
                "ts_ms":          int(time.time() * 1000),
                # Signal attribution chain (5.6)
                "regime":         m.get("regime",            "UNKNOWN"),
                "strategy_type":  s.get("strategy_type",     "UNKNOWN"),
                "z_score":        round(m.get("zScore",       0.0), 4),
                "rsi":            round(m.get("rsi",          50.0), 2),
                "ofi_tanh":       round(m.get("ofi",          0.0), 4),  # tanh (-1,+1)
                "bayesian":       round(m.get("bayesianPosterior", 0.5), 4),
                "confidence":     round(float(s.get("confidence", 0.0)), 4),
                "partial_take_r":  round(float(s.get("partial_take_r", 0.0) or 0.0), 4),
                "partial_take_pct": round(float(s.get("partial_take_pct", 0.0) or 0.0), 4),
                "atr_pct":        round(m.get("atr_pct",      0.0), 6),
                "skewness":       round(m.get("skewness",     0.0), 4),
            }
            res = db.collection("botTrades").add(doc)
            doc_id = res[1].id
            logger.info(f"[Executor] Trade logged to Firestore (ID: {doc_id}) ✓")
            return doc_id
        except Exception as e:
            logger.warning(f"[Executor] Failed to log trade to Firestore: {e}")
            return None

    def _update_trade_exit(self, doc_id: str, exit_price: float, pnl: float):
        """Update an existing trade record with exit metadata."""
        if not doc_id:
            return
        db = heartbeat.get_db()
        if db is None:
            return
        try:
            from firebase_admin import firestore as fs
            result = "WIN" if pnl > 0 else "LOSS"
            db.collection("botTrades").document(doc_id).update({
                "exit_price": exit_price,
                "pnl":        pnl,
                "result":     result,
                "exit_ts":    fs.SERVER_TIMESTAMP,
                "exit_ts_ms": int(time.time() * 1000),
                "status":     "CLOSED",
            })
            logger.info(f"[Executor] Trade {doc_id} exit updated in Firestore ✓")
        except Exception as e:
            logger.warning(f"[Executor] Failed to update trade exit for {doc_id}: {e}")

    def _log_partial_take(self, trade_doc_id: str, partial_size: float,
                          exit_price: float, pnl: float, side: str):
        """Log a partial take-profit execution to Firestore `partialTakes` subcollection."""
        if not trade_doc_id:
            return
        db = heartbeat.get_db()
        if db is None:
            return
        try:
            from firebase_admin import firestore as fs
            doc = {
                "parent_trade_id": trade_doc_id,
                "partial_size":    partial_size,
                "exit_price":      exit_price,
                "pnl":             pnl,
                "side":            side,
                "timestamp":       fs.SERVER_TIMESTAMP,
                "ts_ms":           int(time.time() * 1000),
            }
            db.collection("botTrades").document(trade_doc_id).collection("partialTakes").add(doc)
            logger.info(
                f"[Executor] Partial TP logged: size={partial_size} @ {exit_price:.2f} "
                f"PnL={pnl:.2f} for trade {trade_doc_id} ✓"
            )
        except Exception as e:
            logger.warning(f"[Executor] Failed to log partial take: {e}")

    # ------------------------------------------------------------------
    # Balance
    # ------------------------------------------------------------------
    async def get_usdt_balance(self, account_size: float = 100.0) -> float:
        """Return free stablecoin balance (USDC/USD/USDT) or simulated equity in dry-run."""
        if self.dry_run:
            return account_size
        try:
            bal = await self.exchange.fetch_balance()
            free = bal.get("free", {})
            total = float(free.get("USDT", 0.0)) + float(free.get("USD", 0.0)) + float(free.get("USDC", 0.0))
            if total <= 0:
                return account_size
            return total
        except Exception as e:
            logger.warning(f"[Executor] get_usdt_balance fallback: {e}")
            return account_size

    async def get_btc_balance(self) -> float:
        """Return free BTC balance directly from exchange."""
        if self.dry_run: return 0.0
        try:
            bal = await self.exchange.fetch_balance()
            return float(bal.get("free", {}).get("BTC", 0.0))
        except Exception: return 0.0

    async def get_total_equity(self, current_price: float, account_size: float = 100.0) -> float:
        """
        Calculate total account value: (Sum of Stables) + (BTC * Price).
        Ensures risk (position size) is based on entire portfolio, not just cash.
        """
        if self.dry_run: return account_size
        
        try:
            bal = await self.exchange.fetch_balance()
            free = bal.get("free", {})
            
            cash = float(free.get("USDT", 0.0)) + float(free.get("USD", 0.0)) + float(free.get("USDC", 0.0))
            crypto_val = float(free.get("BTC", 0.0)) * current_price
            
            total = cash + crypto_val
            if total <= 5.0: # If effectively zero, fall back
                return account_size
            
            logger.info(f"[Executor] Equity: Cash=${cash:.2f} + BTC_Val=${crypto_val:.2f} → Total=${total:.2f}")
            return total
        except Exception as e:
            err_msg = f"Failed to calculate total equity: {e}"
            logger.error(f"[Executor] {err_msg}")
            await self.notifier.send_error_alert(err_msg)
            return account_size

    # ------------------------------------------------------------------
    # Position sizing
    # ------------------------------------------------------------------
    def _kelly_scale(self, p: float, rr: float, fraction: float = 0.25) -> float:
        """Fractional Kelly multiplier bounded [0.5, 1.0].

        `max_risk_pct` is a hard ceiling; Kelly may reduce size when edge is
        weak, but it must not increase account risk above the configured cap.
        """
        if rr <= 0 or p <= 0.50 or p >= 1.0:
            return 1.0
        f_star = (p * rr - (1.0 - p)) / rr
        return max(0.5, min(1.0, 1.0 + f_star * fraction))

    def calculate_position_size(
        self,
        current_price: float,
        stop_loss: float,
        equity: float,
        max_risk_pct: float,
        atr_pct: float = 0.005,
        atr_pct_rank: float = 0.5,
        adaptive_mult: float = 1.0,
    ) -> float:
        """
        Vol-normalized position sizing: constant dollar risk regardless of ATR regime.
        Dr. Markov Alternative A: size = risk_usd / (price × atr_pct × adaptive_mult)
        Additional inverse ATR-rank scaling reduces size further in high-vol environments
        where the formula alone would produce larger positions.
        """
        risk_usd = equity * (max_risk_pct / 100.0)
        vol_distance = atr_pct * current_price * adaptive_mult
        stop_distance = abs(current_price - stop_loss)
        if vol_distance <= 0 or current_price <= 0:
            return 0.0
        risk_distance = max(vol_distance, stop_distance)
        fee_distance = (abs(current_price) + abs(stop_loss)) * self.TAKER_FEE
        vol_scale = 1.0 - 0.4 * max(0.0, atr_pct_rank - 0.5)
        return (risk_usd * vol_scale) / max(risk_distance + fee_distance, 1e-9)

    # ------------------------------------------------------------------
    # Signal execution
    # ------------------------------------------------------------------
    def _same_crypto_beta(self, symbol: str) -> bool:
        sym = str(symbol or "").upper()
        return any(base in sym for base in ("BTC", "ETH", "SOL"))

    async def _portfolio_risk_multiplier(self, symbol: str, side: str) -> float:
        """
        Best-effort runtime cross-symbol exposure guard.

        Firestore is the shared state across separate bot processes. When it is
        available, allow one same-direction crypto-beta trade at full risk,
        reduce the second, and block the third. If Firestore is unavailable we
        fail open rather than crashing the executor.
        """
        if self.dry_run:
            return 1.0
        if os.environ.get("BOT_PORTFOLIO_RISK_GUARD", "true").lower() == "false":
            return 1.0
        if not self._same_crypto_beta(symbol):
            return 1.0

        max_same_side = int(os.environ.get("BOT_PORTFOLIO_MAX_SAME_SIDE", "2"))
        full_risk_slots = int(os.environ.get("BOT_PORTFOLIO_FULL_RISK_SLOTS", "1"))
        reduced_mult = float(os.environ.get("BOT_PORTFOLIO_REDUCED_RISK_MULT", "0.50"))
        side_key = "long" if side == "buy" else "short"
        db = heartbeat.get_db()
        if db is None:
            return 1.0

        def _count_open_same_side() -> int:
            cutoff_ms = int((time.time() - 6 * 3600) * 1000)
            try:
                docs = db.collection("botTrades").where("status", "==", "OPEN").stream()
            except Exception:
                return 0
            count = 0
            for doc in docs:
                data = doc.to_dict() or {}
                if data.get("mode") != "LIVE":
                    continue
                if int(data.get("ts_ms") or 0) < cutoff_ms:
                    continue
                if data.get("portfolio_side") != side_key:
                    continue
                if not self._same_crypto_beta(str(data.get("symbol") or "")):
                    continue
                count += 1
            return count

        try:
            open_same_side = await asyncio.to_thread(_count_open_same_side)
        except Exception as exc:
            logger.warning(f"[PortfolioRisk] Guard unavailable, failing open: {exc}")
            return 1.0

        if open_same_side >= max_same_side:
            logger.warning(
                f"[PortfolioRisk] Blocking {side_key.upper()} {symbol}: "
                f"{open_same_side} same-direction crypto-beta trades already open."
            )
            return 0.0
        if open_same_side >= full_risk_slots:
            logger.info(
                f"[PortfolioRisk] Reduced-risk slot for {side_key.upper()} {symbol}: "
                f"{open_same_side} same-direction trade open, risk x{reduced_mult:.2f}."
            )
            return max(0.0, min(1.0, reduced_mult))
        return 1.0

    async def execute_signal(
        self,
        symbol: str,
        current_price: float,
        signal: Dict[str, Any],
        max_risk_pct: float,
        account_size: float = 100.0,
        ulis_verdict: str = "",
        funding_rate: float = 0.0,
    ):
        verdict     = signal.get("verdict", "WAIT")
        confidence  = float(signal.get("confidence", 0))
        stop_loss   = float(signal.get("stop_loss", 0))
        take_profit = float(signal.get("take_profit", 0))

        # Reset bracket sentinel
        self._bracket_handled = False

        # Guard rails
        if "WAIT" in verdict:
            return

        # C3 FIX: Initialise sentinel values BEFORE the lock so they are always
        # defined if emergency_flatten is reached inside the locked block.
        fmt_size = 0.0
        raw_size = 0.0

        # C2+C5 FIX: Acquire lock BEFORE checking or modifying any shared state.
        # This prevents two concurrent candle-close events from both passing the
        # None-check and placing simultaneous orders.  The Semaphore(1) is reentrant
        # so nested calls (check_position_exit → _check_live_position_exit) do not
        # deadlock — only the outermost acquisition increments the counter.
        async with self._position_lock:
            if self.active_position is not None:
                logger.info("[Executor] Already in a position. Skipping new entry.")
                return

            # C5 FIX: pending_order check is now inside the lock — TOCTOU race closed.
            if self.pending_order is not None:
                if time.time() > self.pending_order.get("expires_at", 0):
                    logger.warning(
                        f"[Executor] Pending order {self.pending_order['id']} TTL expired — "
                        "clearing stale state. Verify on exchange if order was filled."
                    )
                    self.pending_order = None
                else:
                    logger.info(f"[Executor] Pending order {self.pending_order['id']} still unfilled. Rejecting new signal.")
                    return

            if stop_loss <= 0 or take_profit <= 0:
                logger.warning("[Executor] Invalid SL/TP. Aborting.")
                return

            side = "buy" if ("BUY" in verdict or "LONG" in verdict) else "sell"
            # AUDIT FIX #6: Use estimated fill price (bid + spread proxy) for SL check.
            # current_price is the bid. BUY orders fill at the ask (~bid + 2bp).
            # Without this, a SL set between bid and ask passes the check but
            # gets immediately hit at fill.
            fill_price_est = current_price * 1.0002 if side == "buy" else current_price * 0.9998
            if side == "buy" and stop_loss >= fill_price_est:
                logger.warning(f"[Executor] SL {stop_loss} ≥ est. fill {fill_price_est:.2f} for BUY. Aborting.")
                return
            if side == "sell" and stop_loss <= fill_price_est:
                logger.warning(f"[Executor] SL {stop_loss} ≤ est. fill {fill_price_est:.2f} for SELL. Aborting.")
                return

            portfolio_mult = await self._portfolio_risk_multiplier(symbol, side)
            if portfolio_mult <= 0.0:
                return
            if portfolio_mult < 1.0:
                max_risk_pct *= portfolio_mult

            # 1. Calculate Available Equity for accurate risk sizing.
            # Futures: Use only available margin (Cash) to prevent oversized rejected orders.
            # Spot: Use Total Equity (Cash + BTC) to size based on full portfolio.
            if self.is_futures:
                equity = await self.get_usdt_balance(account_size)
            else:
                equity = await self.get_total_equity(current_price, account_size)

            if side == "buy":
                usdc_equity = equity
                if usdc_equity < 5:
                    err = f"Insufficient USDC (${usdc_equity:.2f}) to open LONG. Min $5 required."
                    logger.warning(f"[Executor] {err}")
                    await self.notifier.send_error_alert(err)
                    return
            else:
                if self.is_futures:
                    usdc_equity = equity
                    if usdc_equity < 5:
                        err = f"Insufficient USDC margin (${usdc_equity:.2f}) to open SHORT on Binance Futures. Min $5 required."
                        logger.warning(f"[Executor] {err}")
                        await self.notifier.send_error_alert(err)
                        return
                else:
                    # Spot: Need BTC in account to sell
                    btc_bal = await self.get_btc_balance()
                    if btc_bal <= 0.00001:
                        err = f"Aborting SELL signal: No BTC balance available to sell on spot account."
                        logger.warning(f"[Executor] {err}")
                        await self.notifier.send_error_alert(err)
                        return

            _atr_pct = float(signal.get("atr_pct", 0.005))
            _atr_rank = float(signal.get("atr_pct_rank", 0.5))
            _ad_mult = float(signal.get("adaptive_mult", 1.0))
            raw_size = self.calculate_position_size(
                current_price, stop_loss, equity, max_risk_pct,
                atr_pct=_atr_pct, atr_pct_rank=_atr_rank, adaptive_mult=_ad_mult
            )
            _rr = abs(take_profit - current_price) / max(abs(stop_loss - current_price), 1e-9)
            # P1-2 FIX: Clamp confidence to [0, 1] before Kelly scaling to prevent sizing blowouts
            confidence = max(0.0, min(1.0, float(confidence)))
            kelly_mult = self._kelly_scale(confidence, _rr, fraction=0.25)
            raw_size *= kelly_mult
            if raw_size <= 0.0:
                logger.warning("[Executor] Calculated position size is 0. Aborting.")
                return

            # ── Symbol-aware minimum lot size (critical for multi-coin) ────────
            # BTC min lot = 0.001  | ETH = 0.001  | SOL = 0.1  | AVAX = 0.1
            # PEPE = 1  | DOGE = 1  | WIF = 0.1  | Default (unknown) = 5 USDT notional
            # The actual exchange precision is handled by amount_to_precision() below;
            # this check only prevents zero-size rejections before that call.
            _raw_symbol = symbol.upper().replace(":USDT", "").replace(":USDC", "")
            if "/" in _raw_symbol:
                _sym_upper = _raw_symbol.split("/")[0]
            elif "-" in _raw_symbol:
                _sym_upper = _raw_symbol.split("-")[0]
            elif "USDT" in _raw_symbol:
                _sym_upper = _raw_symbol.split("USDT")[0]
            elif "USDC" in _raw_symbol:
                _sym_upper = _raw_symbol.split("USDC")[0]
            elif "USD" in _raw_symbol:
                _sym_upper = _raw_symbol.split("USD")[0]
            else:
                _sym_upper = _raw_symbol
            _MIN_QTY_MAP = {
                "BTC":  0.001,
                "ETH":  0.001,
                "SOL":  0.1,
                "AVAX": 0.1,
                "BNB":  0.01,
                "WIF":  0.1,
                "PEPE": 1.0,
                "DOGE": 1.0,
                "INJ":  0.01,
                "ARB":  0.1,
                "OP":   0.1,
            }
            MIN_QTY = _MIN_QTY_MAP.get(_sym_upper, 0.01)  # safe default for unknown alts
            default_min_notional = 50.5 if (self.is_futures and self.exchange_id == "binanceusdm") else 5.5
            try:
                min_notional = float(os.environ.get("BOT_MIN_NOTIONAL_USD", str(default_min_notional)))
            except (TypeError, ValueError):
                min_notional = default_min_notional
            min_notional = max(0.0, min_notional)

            if raw_size < MIN_QTY:
                sl_dist_pct = abs(current_price - stop_loss) / current_price
                needed_equity = (MIN_QTY * current_price * sl_dist_pct) / (max_risk_pct / 100.0)
                msg = (
                    f"[Executor] ⚠️ Position too small: {raw_size:.6f} {_sym_upper} < min {MIN_QTY}. "
                    f"Need ~${needed_equity:.0f} equity at {max_risk_pct}% risk. "
                    f"Current equity=${equity:.0f}. Deposit or raise BOT_MAX_RISK_PCT."
                )
                logger.error(msg)
                if self.notifier:
                    await self.notifier.send_error_alert(msg)
                return

            if raw_size * current_price < min_notional:
                needed_acct = (min_notional * abs(current_price - stop_loss)) / (max_risk_pct / 100.0)
                logger.error(
                    f"[Executor] Account ${equity:.0f} too small. "
                    f"Notional=${raw_size*current_price:.2f} < min ${min_notional:.2f}. "
                    f"Needs ~${needed_acct:.0f} account. ABORTING order."
                )
                if self.notifier:
                    await self.notifier.send_error_alert(
                        f"⚠️ Account too small: ${equity:.0f} < required ~${needed_acct:.0f}."
                    )
                return

            # H-3 FIX: Hard notional cap. Keep default conservative; allow an
            # intentional override instead of blindly matching exchange leverage.
            max_notional_mult = float(os.environ.get("BOT_MAX_NOTIONAL_MULT", "2.0"))
            max_notional_mult = max(1.0, min(max_notional_mult, 10.0))
            max_notional = equity * max_notional_mult
            if raw_size * current_price > max_notional:
                raw_size = max_notional / current_price
                logger.info(f"[Executor] Position capped to max notional (${max_notional:.2f})")
                if raw_size * current_price < min_notional:
                    logger.error(
                        f"[Executor] Capped notional=${raw_size*current_price:.2f} "
                        f"< min ${min_notional:.2f}. ABORTING order."
                    )
                    if self.notifier:
                        await self.notifier.send_error_alert(
                            f"Account too small after notional cap: "
                            f"${raw_size*current_price:.2f} < min ${min_notional:.2f}."
                        )
                    return

            # Translate symbol to exchange format (unified CCXT symbol)
            if self.exchange_id == "coinbase":
                ex_symbol = self._to_exchange_symbol(symbol)
            else:
                ex_symbol = self._get_ccxt_symbol(symbol)

            fmt_size = float(self.exchange.amount_to_precision(ex_symbol, raw_size))
            if fmt_size < MIN_QTY:
                logger.warning(f"[Executor] fmt_size {fmt_size} < min qty {MIN_QTY} for {_sym_upper}. Aborting.")
                return

            # For Coinbase, ensure the symbol is in the markets cache
            if self.exchange_id == "coinbase":
                if ex_symbol not in self.exchange.markets or self.exchange.markets.get(ex_symbol) is None:
                    # Try to add it to markets cache if missing
                    logger.warning(f"[Executor] Symbol {ex_symbol} not in markets cache. Attempting to register...")
                    if not hasattr(self.exchange, 'markets') or self.exchange.markets is None:
                        self.exchange.markets = {}

                    # Use default market spec for BTC/USDC or BTC/USD
                    if "BTC" in ex_symbol.upper() and "USDC" in ex_symbol.upper():
                        self.exchange.markets['BTC/USDC'] = {
                            'id': 'BTC-USDC', 'symbol': 'BTC/USDC', 'base': 'BTC', 'quote': 'USDC',
                            'precision': {'amount': 0.00000001, 'price': 0.01},
                            'limits': {'amount': {'min': 0.00001, 'max': 1000}, 'price': {'min': 0.01, 'max': 1000000}, 'cost': {'min': 1.0}},
                            'active': True, 'type': 'spot', 'spot': True, 'margin': False, 'contract': False
                        }
                        logger.info("[Executor] Registered BTC/USDC to markets cache.")
                    elif "BTC" in ex_symbol.upper() and "USD" in ex_symbol.upper():
                        self.exchange.markets['BTC/USD'] = {
                            'id': 'BTC-USD', 'symbol': 'BTC/USD', 'base': 'BTC', 'quote': 'USD',
                            'precision': {'amount': 0.00000001, 'price': 0.01},
                            'limits': {'amount': {'min': 0.00001, 'max': 1000}, 'price': {'min': 0.01, 'max': 1000000}, 'cost': {'min': 1.0}},
                            'active': True, 'type': 'spot', 'spot': True, 'margin': False, 'contract': False
                        }
                        logger.info("[Executor] Registered BTC/USD to markets cache.")

        if self.dry_run:
            # ── DRY RUN ──────────────────────────────────────────────────
            # P0 FIX: Do NOT await inside _position_lock. send_trade_alert makes
            # an unbounded network call (Telegram). Holding the lock across it
            # blocks the heartbeat from checking exits. Move alert to AFTER
            # the lock is released. State writes (active_position, _log_trade)
            # stay inside the lock — they are atomic.
            #
            # P2 FIX: Dynamic slippage. Flat 0.02% is too optimistic for volatile
            # markets (sweeps gap 5-15 bps). Use max(0.02%, atr_pct * 0.15) so
            # a 0.30% ATR → 4.5 bps slippage — realistic for BTCUSDT sweeps.
            SLIPPAGE_PCT = max(0.0002, _atr_pct * 0.15)
            fill_price = (
                current_price * (1.0 + SLIPPAGE_PCT) if side == "buy"
                else current_price * (1.0 - SLIPPAGE_PCT)
            )
            cost = raw_size * fill_price
            logger.info(
                f"[DRY-RUN] {verdict} {ex_symbol} "
                f"| qty={raw_size:.6f} (${cost:.2f}) "
                f"| fill~{fill_price:.2f} (slip={SLIPPAGE_PCT:.2%}) "
                f"| SL={stop_loss} TP={take_profit} "
                f"| equity=${equity:.2f} risk={max_risk_pct}% "
                f"| ULIS={ulis_verdict}"
            )
            doc_id = self._log_trade(
                ex_symbol, side, verdict, fill_price, stop_loss, take_profit,
                ulis_verdict, signal=signal, size=raw_size
            )
            initial_risk_dist = abs(fill_price - stop_loss)
            self.active_position = {
                "symbol":           ex_symbol,
                "side":             side,
                "size":             raw_size,
                "entry_price":      fill_price,
                "stop_loss":        stop_loss,
                "initial_stop_loss": stop_loss,
                "initial_risk_dist": initial_risk_dist,
                "take_profit":      take_profit,
                "entry_direction":  verdict,
                "strategy_type":     signal.get("strategy_type", "UNKNOWN"),
                "dry_run":          True,
                "trade_doc_id":     doc_id,
                "be_lock_trigger":  signal.get("be_lock_trigger", 1.0),
                "partial_take_r":   signal.get("partial_take_r", 0.75),
                "partial_take_pct": signal.get("partial_take_pct", 0.50),
                "_partial_taken":   False,
                "realized_partial_pnl": 0.0,
                "time_exit_sec":    signal.get("time_exit_sec", 600),
                "time_exit_hard_cap_s": signal.get("time_exit_hard_cap_s", 1200),
                "regime":           signal.get("regime", "NEUTRAL"),
                "atr_at_entry":     signal.get("atr_at_entry", 0.0),
                "entry_ts":         time.time(),
                # D2 FIX: Dry-run has no exchange bracket legs, but the
                # simulated position is fully represented by local SL/TP logic.
                "bracket_status":       "DRY_RUN",
                "bracket_missing_leg":  None,
                "last_bracket_check_ts": time.time(),
            }
            # Lock released here — Telegram call is outside the critical section
            await self.notifier.send_trade_alert(
                symbol=ex_symbol, side=side, price=current_price,
                size=raw_size, sl=stop_loss, tp=take_profit, is_dry=True
            )
            return

        # ── LIVE EXECUTION (MAKER-ONLY) ────────────────────────────────────
        # Guard: if the last order failed (e.g. -2015), wait before retrying.
        if time.time() < self.failed_order_ts:
            remaining = int(self.failed_order_ts - time.time())
            logger.info(f"[Executor] Failed-order cooldown active — {remaining}s remaining. Skipping.")
            return

        # P5 FIX: Set pending_order INFLIGHT BEFORE releasing the outer lock.
        self.pending_order = {
            "id": None,
            "symbol": None,
            "side": None,
            "size": None,
            "entry_price": None,
            "status": "INFLIGHT",
            "expires_at": time.time() + 60,
        }

        try:
            if self.exchange_id == "coinbase" and "USDC" in ex_symbol:
                ex_symbol = ex_symbol.replace("USDC", "USD")
                
            fmt_size = float(self.exchange.amount_to_precision(ex_symbol, raw_size))
            cost = fmt_size * current_price
            if cost > equity:
                fmt_size = float(
                    self.exchange.amount_to_precision(ex_symbol, equity * 0.95 / current_price)
                )
                cost = fmt_size * current_price

            min_live_rr = self._min_live_entry_rr()
            prefill_rr = self._effective_reward_risk(side, current_price, stop_loss, take_profit)
            if prefill_rr < min_live_rr:
                logger.warning(
                    f"[Executor] Live entry skipped: effective RR={prefill_rr:.2f} "
                    f"< min {min_live_rr:.2f} after price drift "
                    f"(entry~{current_price}, SL={stop_loss}, TP={take_profit})."
                )
                self.pending_order = None
                return False

            # ── MAKER-ONLY ENTRY: Limit order at best bid/ask with postOnly ─
            import asyncio
            ORDER_TTL_SEC = 60
            POLL_INTERVAL_S = 3.0

            # Determine limit price from live order book (best bid/ask)
            try:
                ob = await self.exchange.fetch_order_book(ex_symbol, 1)
                if side == "buy":
                    limit_price = ob['bids'][0][0] if ob.get('bids') and ob['bids'][0][0] > 0 else current_price * 0.9998
                else:
                    limit_price = ob['asks'][0][0] if ob.get('asks') and ob['asks'][0][0] > 0 else current_price * 1.0002
            except Exception:
                # Fallback to spread assumption (2bp)
                limit_price = current_price * 0.9998 if side == "buy" else current_price * 1.0002

            order = None
            for attempt in range(3):
                try:
                    limit_p = float(self.exchange.price_to_precision(ex_symbol, limit_price))
                    if self.exchange_id == "coinbase" and not self.is_futures:
                        order = await self.exchange.create_limit_order(
                            ex_symbol, side, fmt_size, limit_p,
                            params={"postOnly": True}
                        )
                    else:
                        order = await self.exchange.create_order(
                            ex_symbol, "LIMIT", side, fmt_size, limit_p,
                            params={"postOnly": True, "timeInForce": "GTC"}
                        )
                    break
                except Exception as e:
                    if attempt == 2:
                        self.failed_order_ts = time.time() + 90.0
                        logger.error(f"[Executor] Limit order failed after 3 attempts: {e}")
                        raise e
                    logger.warning(f"[Executor] Limit order attempt {attempt+1}/3 failed: {e}. Retrying...")
                    await asyncio.sleep(0.5)

            order_id = order.get("id")
            logger.info(
                f"[MakerEntry] LIMIT {side.upper()} {fmt_size} {ex_symbol} "
                f"@ {limit_price:.2f} | id={order_id} | postOnly=True | TTL={ORDER_TTL_SEC}s"
            )
            self.pending_order = {
                "id": order_id,
                "symbol": ex_symbol,
                "side": side,
                "size": fmt_size,
                "entry_price": limit_price,
                "status": "PENDING",
                "expires_at": time.time() + ORDER_TTL_SEC,
            }

            # ── TTL Polling Loop — monitor fill progress ──────────────────
            deadline = time.time() + ORDER_TTL_SEC
            filled = 0.0
            fill_price = limit_price
            order_status = "open"

            while time.time() < deadline:
                await asyncio.sleep(POLL_INTERVAL_S)
                try:
                    updated = await self.exchange.fetch_order(order_id, ex_symbol)
                except Exception as fetch_err:
                    logger.warning(f"[MakerEntry] fetch_order error: {fetch_err}. Retrying in next poll.")
                    continue

                order_status = updated.get("status", "open")
                filled = float(updated.get("filled", 0.0) or 0.0)
                avg = updated.get("average")
                if avg is not None:
                    fill_price = float(avg)

                if order_status == "closed":
                    logger.info(f"[MakerEntry] Fully filled. size={filled} avg={fill_price:.2f}")
                    break
                elif order_status in ("canceled", "expired", "rejected"):
                    logger.warning(f"[MakerEntry] Order {order_status}. Aborting entry.")
                    self.pending_order = None
                    return False

            if filled <= 0.0:
                logger.warning("[MakerEntry] Not filled within TTL. Cancelling and aborting.")
                try:
                    await self.exchange.cancel_order(order_id, ex_symbol)
                except Exception:
                    pass
                self.pending_order = None
                return False

            # ── Partial Fill Handling ─────────────────────────────────────
            if filled < fmt_size:
                logger.info(
                    f"[MakerEntry] Partial fill: {filled}/{fmt_size} {ex_symbol}. "
                    "Cancelling remaining and scaling position."
                )
                try:
                    await self.exchange.cancel_order(order_id, ex_symbol)
                except Exception:
                    pass
                fmt_size = float(self.exchange.amount_to_precision(ex_symbol, filled))
                if fmt_size <= 0.0:
                    logger.error("[MakerEntry] Partial fill rounded to 0. Aborting.")
                    self.pending_order = None
                    return False

            # Fee estimation: use maker rate for limit entry
            entry_fee_actual = 0.0
            entry_fee_est = abs(fill_price * fmt_size * self.MAKER_FEE)
            logger.info(
                f"[MakerEntry] Fill: price={fill_price:.2f} size={fmt_size} "
                f"(signal ~{current_price:.2f}, diff={fill_price-current_price:+.2f}) "
                f"maker_fee_est={entry_fee_est:.4f}"
            )

            fill_rr = self._effective_reward_risk(side, fill_price, stop_loss, take_profit)
            if fill_rr < min_live_rr:
                logger.warning(
                    f"[Executor] Fill degraded RR to {fill_rr:.2f} < min {min_live_rr:.2f}. "
                    "Flattening immediately instead of holding bad geometry."
                )
                close_side = "sell" if side == "buy" else "buy"
                flatten_params = {"reduceOnly": True} if self.is_futures else {}
                try:
                    await self.exchange.create_market_order(ex_symbol, close_side, fmt_size, params=flatten_params)
                    logger.info("[Executor] Low-RR fill flattened successfully.")
                except Exception as flatten_err:
                    logger.critical(
                        f"[Executor] Low-RR fill flatten FAILED for {ex_symbol}: {flatten_err}. "
                        "Manual intervention required."
                    )
                    self._flatten_failed = True
                    if self.notifier:
                        await self.notifier.send_error_alert(
                            f"Low-RR fill flatten failed for {ex_symbol}: {flatten_err}"
                        )
                self.pending_order = None
                return False
            trade_doc_id = None
            
            # Track this order as pending until it fills or is cancelled
            # MED-5 FIX: Add TTL so a stale pending_order can't lock the bot forever.
            self.pending_order = {
                "id": order.get('id'),
                "symbol": ex_symbol,
                "side": side,
                "size": fmt_size,
                "entry_price": current_price,
                "status": order.get('status', 'open'),
                "expires_at": time.time() + 60,  # auto-expire after 60s if never confirmed
            }
            
            # Telegram Notification (Success)
            await self.notifier.send_trade_alert(
                symbol=ex_symbol, side=side, price=current_price, 
                size=fmt_size, sl=stop_loss, tp=take_profit, is_dry=False
            )

            sl_side = "sell" if side == "buy" else "buy"
            sl_order_id = None
            tp_order_id = None
            sl_placed = False   # track independently for recovery logic
            tp_placed = False

            def _activate_position(current_tp_order_id=None, current_tp_placed=False):
                nonlocal trade_doc_id
                if trade_doc_id is None:
                    trade_doc_id = self._log_trade(
                        ex_symbol, side, verdict, fill_price, stop_loss, take_profit,
                        ulis_verdict, signal=signal, size=fmt_size
                    )
                initial_risk_dist = abs(fill_price - stop_loss)
                self.active_position = {
                    "symbol":           ex_symbol,
                    "side":             side,
                    "size":             fmt_size,
                    "entry_price":      fill_price,
                    "entry_fee":        entry_fee_actual or entry_fee_est,
                    "entry_fee_est":    entry_fee_est,
                    "stop_loss":        stop_loss,
                    "initial_stop_loss": stop_loss,
                    "initial_risk_dist": initial_risk_dist,
                    "take_profit":      take_profit,
                    "entry_direction":  verdict,
                    "strategy_type":     signal.get("strategy_type", "UNKNOWN"),
                    "order_id":         order.get("id"),
                    "sl_order_id":      sl_order_id,
                    "tp_order_id":      current_tp_order_id,
                    "sl_placed":        sl_placed,
                    "tp_placed":        current_tp_placed,
                    "dry_run":          False,
                    "trade_doc_id":     trade_doc_id,
                    "be_lock_trigger":  signal.get("be_lock_trigger", 1.0),
                    "partial_take_r":   signal.get("partial_take_r", 0.75),
                    "partial_take_pct": signal.get("partial_take_pct", 0.50),
                    "_partial_taken":   False,
                    "realized_partial_pnl": 0.0,
                    "time_exit_sec":    signal.get("time_exit_sec", 600),
                    "time_exit_hard_cap_s": signal.get("time_exit_hard_cap_s", 1200),
                    "regime":           signal.get("regime", "NEUTRAL"),
                    "atr_at_entry":     signal.get("atr_at_entry", 0.0),
                    "entry_ts":         time.time(),
                    # D2 FIX: Explicit bracket status for live positions.
                    "bracket_status":       "BRACKETED" if (sl_placed and current_tp_placed) else "SL_ONLY",
                    "bracket_missing_leg":  None if (sl_placed and current_tp_placed) else ("TP" if sl_placed else "SL"),
                    "last_bracket_check_ts": time.time(),
                }

            if self.is_futures:
                # ── FUTURES: Batch bracket placement using USD-M compatible orders ─
                # Try batch orders first (preferred), then individual orders sequentially.
                # If any leg fails, cancel sibling and emergency-flatten per plan spec.
                atr_for_sl = signal.get("atr_at_entry", 0.0)
                atr_multiplier = 0.015 if (side == "sell" and funding_rate > 0.00008) else 0.02
                sl_limit_price = float(self.exchange.price_to_precision(
                    ex_symbol,
                    stop_loss + (atr_for_sl * atr_multiplier) if side == "buy" else stop_loss - (atr_for_sl * atr_multiplier)
                ))

                # NOTE: Binance Futures does NOT support TAKE_PROFIT_LIMIT in batch orders.
                # Batch TP stays as TAKE_PROFIT_MARKET (taker). Individual TP path below
                # attempts TAKE_PROFIT_LIMIT with postOnly for maker fees, falling back to
                # TAKE_PROFIT_MARKET on rejection. The main fee savings come from the
                # LIMIT entry (maker), not the TP.
                tp_limit_offset = 1.0005 if sl_side == "sell" else 0.9995
                tp_limit_price = float(self.exchange.price_to_precision(
                    ex_symbol, take_profit * tp_limit_offset
                ))

                batch_orders = [
                    {
                        "symbol": ex_symbol,
                        "type": "STOP",
                        "side": sl_side,
                        "amount": fmt_size,
                        "price": sl_limit_price,
                        "params": {
                            "stopPrice": float(self.exchange.price_to_precision(ex_symbol, stop_loss)),
                            "reduceOnly": True,
                        },
                    },
                    {
                        "symbol": ex_symbol,
                        "type": "TAKE_PROFIT_MARKET",
                        "side": sl_side,
                        "amount": fmt_size,
                        "params": {
                            "stopPrice": float(self.exchange.price_to_precision(ex_symbol, take_profit)),
                            "reduceOnly": True,
                            "workingType": "MARK_PRICE",
                        },
                    },
                ]

                sl_order_id = None
                tp_order_id = None
                bracket_accepted = False

                # Attempt 1: Batch orders (preferred for atomicity)
                try:
                    batch_result = await self.exchange.create_orders(batch_orders)
                    sl_order_id = batch_result[0].get("id")
                    tp_order_id = batch_result[1].get("id")
                    sl_placed = True
                    tp_placed = True
                    bracket_accepted = True
                    logger.info(f"[Executor] Futures batch bracket placed: SL={sl_order_id}, TP={tp_order_id}")
                except Exception as batch_err:
                    logger.warning(f"[Executor] Batch orders failed ({batch_err}). Trying individual orders...")
                    # Attempt 2: Individual orders sequentially
                    sl_placed = False
                    tp_placed = False
                    _sl_err = None
                    _tp_err = None

                    for attempt in range(3):
                        try:
                            sl_order = await self.exchange.create_order(
                                symbol=ex_symbol, type="STOP", side=sl_side,
                                amount=fmt_size, price=sl_limit_price,
                                params={
                                    "stopPrice": float(self.exchange.price_to_precision(ex_symbol, stop_loss)),
                                    "reduceOnly": True,
                                },
                            )
                            sl_placed = True
                            sl_order_id = sl_order.get("id")
                            logger.info(f"[Executor] Futures SL placed individually: {sl_order_id}")
                            break
                        except Exception as e:
                            _sl_err = e
                            if attempt < 2:
                                await asyncio.sleep(1.0)

                    for attempt in range(3):
                        try:
                            # MAKER-ONLY TP: try TAKE_PROFIT_LIMIT with postOnly first.
                            # Fall back to TAKE_PROFIT_MARKET (taker) if exchange rejects postOnly.
                            tp_params = {
                                "stopPrice": float(self.exchange.price_to_precision(ex_symbol, take_profit)),
                                "price": tp_limit_price,
                                "reduceOnly": True,
                                "workingType": "MARK_PRICE",
                                "postOnly": True,
                            }
                            tp_type = "TAKE_PROFIT_LIMIT"
                            try:
                                tp_order = await self.exchange.create_order(
                                    symbol=ex_symbol, type=tp_type, side=sl_side,
                                    amount=fmt_size, price=tp_limit_price,
                                    params=tp_params,
                                )
                            except Exception:
                                # postOnly may be rejected by some exchanges — fall back to taker TP
                                logger.info("[Executor] postOnly TP rejected. Falling back to TAKE_PROFIT_MARKET.")
                                tp_params.pop("postOnly", None)
                                tp_params.pop("price", None)
                                tp_type = "TAKE_PROFIT_MARKET"
                                tp_order = await self.exchange.create_order(
                                    symbol=ex_symbol, type=tp_type, side=sl_side,
                                    amount=fmt_size, params=tp_params,
                                )
                            tp_placed = True
                            tp_order_id = tp_order.get("id")
                            logger.info(f"[Executor] Futures TP placed individually ({tp_type}): {tp_order_id}")
                            break
                        except Exception as e:
                            _tp_err = e
                            if attempt < 2:
                                await asyncio.sleep(1.0)

                    if not sl_placed or not tp_placed:
                        failed_leg = "SL" if not sl_placed else "TP"
                        sibling_leg_id = tp_order_id if not sl_placed else sl_order_id
                        sibling_leg_type = "TP" if not sl_placed else "SL"
                        logger.error(f"[Executor] {failed_leg} failed after all attempts. Cancelling sibling {sibling_leg_type} (id={sibling_leg_id}) and flattening.")
                        if sibling_leg_id:
                            try:
                                await self.exchange.cancel_order(sibling_leg_id, ex_symbol)
                                logger.info(f"[Executor] Cancelled {sibling_leg_type} order {sibling_leg_id}")
                            except Exception as cancel_err:
                                logger.warning(f"[Executor] Could not cancel {sibling_leg_type}: {cancel_err}")
                        flatten_side = "sell" if side == "buy" else "buy"
                        try:
                            await self.exchange.create_market_order(ex_symbol, flatten_side, fmt_size, params={"reduceOnly": True})
                            logger.info(f"[Executor] Emergency flatten executed.")
                        except Exception as flatten_err:
                            logger.critical(f"[Executor] Emergency flatten FAILED: {flatten_err}. MANUAL INTERVENTION REQUIRED.")
                            self._flatten_failed = True
                        self._bracket_handled = True
                        raise RuntimeError(f"Bracket placement failed: {failed_leg} leg rejected")

                _activate_position(tp_order_id, tp_placed)

            else:
                # ── SPOT: Exchange-specific limit SL/TP orders ────────────────
                sl_limit = stop_loss * 0.999 if side == "buy" else stop_loss * 1.001
                sl_order = None
                _sl_last_err = None
                for attempt in range(3):
                    try:
                        if self.exchange_id == "binance":
                            sl_order = await self.exchange.create_order(
                                symbol=ex_symbol, type="STOP_LOSS_LIMIT", side=sl_side,
                                amount=fmt_size,
                                price=float(self.exchange.price_to_precision(ex_symbol, sl_limit)),
                                params={"stopPrice": float(self.exchange.price_to_precision(ex_symbol, stop_loss))},
                            )
                        else:
                            # Coinbase Advanced Trade V3 specific stop directions
                            stop_params = {"stop_price": float(self.exchange.price_to_precision(ex_symbol, stop_loss))}
                            if self.exchange_id == "coinbase":
                                direction = "STOP_DIRECTION_STOP_UP" if stop_loss > current_price else "STOP_DIRECTION_STOP_DOWN"
                                # Note: STOP_UP means trigger when price rises ABOVE stop_price (for shorts/longs),
                                # STOP_DOWN means trigger when price drops BELOW stop_price (for longs).
                                # This works correctly for both BUY and SELL positions due to how
                                # Coinbase interprets the direction relative to the order side.
                                stop_params["stop_direction"] = direction
                                
                            sl_order = await self.exchange.create_order(
                                symbol=ex_symbol, type="limit", side=sl_side,
                                amount=fmt_size,
                                price=float(self.exchange.price_to_precision(ex_symbol, sl_limit)),
                                params=stop_params,
                            )
                        sl_placed = True
                        break
                    except Exception as e:
                        _sl_last_err = e
                        logger.warning(f"[Executor] SL attempt {attempt+1}/3 failed: {e}")
                        if attempt < 2:
                            await asyncio.sleep(1.0)
                if not sl_placed:
                    raise RuntimeError(f"SL placement failed after 3 attempts: {_sl_last_err}")
                sl_order_id = sl_order.get("id")
                _activate_position()
                logger.info(f"[Executor] SL attached at {stop_loss} (id={sl_order_id}) ✓")

                # Take-profit limit order
                tp_order = None
                _tp_last_err = None
                for attempt in range(3):
                    try:
                        tp_order = await self.exchange.create_order(
                            symbol=ex_symbol,
                            type="limit",
                            side=sl_side,
                            amount=fmt_size,
                            price=float(self.exchange.price_to_precision(ex_symbol, take_profit)),
                            params={"timeInForce": "GTC"},
                        )
                        tp_placed = True
                        break
                    except Exception as e:
                        _tp_last_err = e
                        logger.warning(f"[Executor] TP attempt {attempt+1}/3 failed: {e}")
                        if attempt < 2:
                            await asyncio.sleep(1.0)
                if not tp_placed:
                    _tp_warn = (
                        f"⚠️ TP PLACEMENT FAILED for {side.upper()} {ex_symbol} @ {current_price}. "
                        f"SL={stop_loss} IS active (id={sl_order_id}). "
                        f"Position protected but NO take-profit. MONITOR MANUALLY."
                    )
                    logger.error(f"[Executor] {_tp_warn}")
                    await self.notifier.send_error_alert(_tp_warn)
                    tp_order_id = None
                else:
                    tp_order_id = tp_order.get("id")
                    logger.info(f"[Executor] TP attached at {take_profit} (id={tp_order_id}) ✓")

            # BUG-1 FIX: Use actual exchange fill price, not signal price.
            # Market orders fill at the ask (for buys) — using current_price
            # corrupts every downstream calculation (PnL, BE stop, daily limit).
            if self.active_position is None:
                _activate_position(tp_order_id, tp_placed)
            else:
                self.active_position["tp_order_id"] = tp_order_id
                self.active_position["tp_placed"] = tp_placed
            # Clear pending order since we now have an active position
            self.pending_order = None

            sl_tp_status = "SL+TP ✓" if (sl_placed and tp_placed) else ("SL ✓ | TP ✗ MONITOR" if sl_placed else "⚠️ NAKED")
            logger.info(f"[Executor] Position open — protection status: {sl_tp_status}")
            await self.notifier.send_trade_alert(
                symbol=ex_symbol, side=side, price=current_price,
                size=fmt_size, sl=stop_loss, tp=take_profit, is_dry=False
            )
            return True


        except ccxt.InsufficientFunds as e:
            logger.error(f"[Executor] Insufficient funds: {e}")
        except ccxt.InvalidOrder as e:
            logger.error(f"[Executor] Invalid order: {e}")
        except Exception as e:
            err_msg = f"Live order / SL placement failed: {e}"
            logger.error(f"[Executor] {err_msg}", exc_info=True)

            # ── EMERGENCY: SL failed — position is NAKED. Flatten immediately. ──
            # Note: TP-only failures are handled above and do NOT reach here —
            # the position keeps its SL in that case and is therefore still protected.
            # Also skip if _bracket_handled is True — that means the bracket fallback
            # already cancelled the sibling and flattened internally.
            if getattr(self, '_bracket_handled', False):
                logger.info("[Executor] _bracket_handled=True — skipping outer emergency flatten.")
                self._bracket_handled = False
            elif self.active_position is None and 'order' in locals() and order and order.get('id'):
                critical_msg = (
                    f"🚨 CRITICAL: SL PLACEMENT FAILED after market fill! "
                    f"FLATTENING NAKED {side.upper()} {ex_symbol} NOW. Error: {e}"
                )
                logger.critical(f"[Executor] {critical_msg}")
                await self.notifier.send_error_alert(critical_msg)

                close_side = "sell" if side == "buy" else "buy"
                try:
                    await self.exchange.create_market_order(ex_symbol, close_side, fmt_size)
                    logger.info("[Executor] ✓ Naked position flattened successfully.")
                    await self.notifier.send_error_alert(
                        f"✅ Naked {side.upper()} {ex_symbol} position flattened. No unintended exposure remains."
                    )
                except Exception as flatten_err:
                    manual_msg = (
                        f"🚨🚨 CRITICAL FAILURE: Could not flatten naked {side.upper()} {ex_symbol} position! "
                        f"MANUAL INTERVENTION REQUIRED IMMEDIATELY! Flatten error: {flatten_err}"
                    )
                    logger.critical(f"[Executor] {manual_msg}")
                    await self.notifier.send_error_alert(manual_msg)
            else:
                await self.notifier.send_error_alert(err_msg)

        finally:
            # If we don't have an active position after all that,
            # we MUST clear pending_order so the bot isn't stuck "Waiting"
            if self.active_position is None:
                self.pending_order = None

    # ------------------------------------------------------------------
    # Position monitor (called from main loop for dry-run)
    # ------------------------------------------------------------------

    async def move_sl_to_breakeven(self, symbol: str, entry_price: float):
        """Moves the current Stop Loss to the entry price (Breakeven).
        FEE-BUFFER FIX: Ofsets the breakeven price by the taker fee to cover the exit
        leg cost. Without this, hitting BE on a limit/market exit still nets a loss
        because the round-trip fee is 0.08% on Binance Futures.
        """
        side = self.active_position.get("side", "buy") if self.active_position else "buy"
        fee_buffer = entry_price * self.TAKER_FEE
        be_price = entry_price + fee_buffer if side == "buy" else entry_price - fee_buffer

        if self.dry_run:
            logger.info(f"[Executor] DRY-RUN: Simulated moving SL to breakeven+fees @ {be_price:.2f} (buffer={fee_buffer:.2f}).")
            if self.active_position:
                self.active_position["stop_loss"] = be_price
            return

        logger.info(f"[Executor] Moving Stop Loss to Breakeven+fees @ {be_price:.2f} "
                     f"(entry={entry_price:.2f}, fee_buffer={fee_buffer:.2f})")
        try:
            if not self.active_position:
                return
                
            # Phase 1: Place the NEW Stop Loss FIRST
            # This ensures we NEVER have a naked position if the API fails
            fmt_size = self.exchange.amount_to_precision(symbol, self.active_position["size"])
            close_side = "sell" if self.active_position["side"] == "buy" else "buy"
            
            new_order = await self.exchange.create_order(
                symbol,
                "STOP_MARKET",
                close_side,
                fmt_size,
                None,
                params={
                    "stopPrice": float(self.exchange.price_to_precision(symbol, be_price)),
                    "reduceOnly": True
                }
            )
            logger.info("[Executor] Phase 1 Success: New Breakeven+fees SL safely placed on exchange.")
            self.active_position["stop_loss"] = be_price
            self.active_position["sl_order_id"] = new_order.get("id")
            self.active_position["sl_placed"] = True
            
            # Phase 2: Now that new SL is secure, cancel the OLD Stop Loss
            open_orders = await self.exchange.fetch_open_orders(symbol)
            for order in open_orders:
                is_stop = order.get("type", "").lower() in ("stop", "stop_market", "stopmarket")
                is_not_new = str(order.get("id")) != str(new_order.get("id"))
                if is_stop and is_not_new:
                    await self.exchange.cancel_order(order["id"], symbol)
                    logger.debug(f"[Executor] Phase 2 Success: Cancelled old SL order {order['id']}")
            
            if hasattr(self, "notifier") and self.notifier:
                await self.notifier.send_message(f"🔒 **Breakeven+fees Secured**\
Moved Stop Loss to {be_price:.2f} (entry={entry_price:.2f} + fee buffer) for {symbol}.")
                    
        except Exception as e:
            # If Phase 1 fails, Phase 2 never runs. The original Stop Loss remains active.
            # Your capital is still fully protected.
            err_msg = f"Failed to move SL to breakeven on Live Exchange: {e}"
            logger.error(f"[Executor] CRITICAL: {err_msg}")
            if hasattr(self, "notifier") and self.notifier:
                await self.notifier.send_error_alert(f"⚠️ **Breakeven Move Failed!**\
{err_msg}\
*Note: Original Stop Loss is still active.*")

    def _estimate_partial_pnl(self, pos: dict, exit_price: float, partial_size: float) -> float:
        entry = float(pos.get("entry_price") or exit_price)
        side = pos.get("side", "buy")
        raw = (exit_price - entry) * partial_size if side == "buy" else (entry - exit_price) * partial_size
        fees = (entry + exit_price) * partial_size * self.TAKER_FEE
        return raw - fees

    def _effective_reward_risk(self, side: str, entry_price: float, stop_loss: float, take_profit: float) -> float:
        risk = entry_price - stop_loss if side == "buy" else stop_loss - entry_price
        reward = take_profit - entry_price if side == "buy" else entry_price - take_profit
        if risk <= 0.0 or reward <= 0.0:
            return 0.0
        return reward / risk

    def _min_live_entry_rr(self) -> float:
        try:
            return max(1.0, float(os.environ.get("BOT_MIN_LIVE_ENTRY_RR", "1.35")))
        except (TypeError, ValueError):
            return 1.35

    def _scale_entry_fees_for_partial(self, pos: dict, original_size: float, remaining_size: float) -> None:
        if original_size <= 0.0:
            return
        remaining_ratio = max(0.0, remaining_size) / original_size
        for key in ("entry_fee", "entry_fee_est"):
            if pos.get(key) is not None:
                pos[key] = self._float_or_zero(pos.get(key)) * remaining_ratio

    async def _restore_reduced_exit_orders(
        self,
        pos: dict,
        remaining_size: float,
        desired_stop_loss: float | None = None,
    ) -> bool:
        """Rebuild futures SL/TP orders after a live partial close."""
        if not self.is_futures:
            return False

        symbol = pos["symbol"]
        close_side = "sell" if pos.get("side") == "buy" else "buy"
        stop_loss = float(desired_stop_loss if desired_stop_loss is not None else (pos.get("stop_loss") or 0.0))
        take_profit = float(pos.get("take_profit") or 0.0)
        fmt_remaining = float(self.exchange.amount_to_precision(symbol, remaining_size))
        if fmt_remaining <= 0.0 or stop_loss <= 0.0:
            return False

        old_sl_order_id = pos.get("sl_order_id")
        old_tp_order_id = pos.get("tp_order_id")

        try:
            sl_order = await self.exchange.create_order(
                symbol=symbol,
                type="STOP_MARKET",
                side=close_side,
                amount=fmt_remaining,
                params={
                    "stopPrice": float(self.exchange.price_to_precision(symbol, stop_loss)),
                    "reduceOnly": True,
                    "workingType": "MARK_PRICE",
                },
            )
        except Exception as e:
            logger.error(
                f"[Executor] Partial TP: replacement SL rejected at {stop_loss}: {e}. "
                "Leaving existing exchange protection in place."
            )
            return False

        if old_sl_order_id:
            try:
                await self.exchange.cancel_order(old_sl_order_id, symbol)
            except Exception as e:
                logger.warning(f"[Executor] Partial TP: old SL cancel failed ({old_sl_order_id}): {e}")

        tp_order = None
        if take_profit > 0.0:
            try:
                tp_order = await self.exchange.create_order(
                    symbol=symbol,
                    type="TAKE_PROFIT_MARKET",
                    side=close_side,
                    amount=fmt_remaining,
                    params={
                        "stopPrice": float(self.exchange.price_to_precision(symbol, take_profit)),
                        "reduceOnly": True,
                        "workingType": "MARK_PRICE",
                    },
                )
            except Exception as e:
                logger.warning(f"[Executor] Partial TP: replacement TP rejected at {take_profit}: {e}")
                pos["requeue_tp_attempts"] = 1
                pos["requeue_tp_side"] = close_side
                pos["requeue_tp_size"] = fmt_remaining
                pos["requeue_tp_price"] = float(self.exchange.price_to_precision(symbol, take_profit))
                pos["requeue_tp_symbol"] = symbol

        if tp_order and old_tp_order_id:
            try:
                await self.exchange.cancel_order(old_tp_order_id, symbol)
            except Exception as e:
                logger.warning(f"[Executor] Partial TP: old TP cancel failed ({old_tp_order_id}): {e}")

        pos["size"] = fmt_remaining
        pos["stop_loss"] = stop_loss
        pos["sl_order_id"] = sl_order.get("id")
        pos["tp_order_id"] = tp_order.get("id") if tp_order else None
        pos["sl_placed"] = True
        pos["tp_placed"] = bool(tp_order)
        if pos.get("requeue_tp_size"):
            pos["requeue_tp_size"] = fmt_remaining
        return True

    async def _maybe_take_partial_profit(self, current_price: float) -> None:
        # PARTIAL TP DISABLED — let trades run to full TP or SL/BE.
        # Rationale: partial take at 0.6R caps max upside to ~1.45R instead of 2.3R.
        # Without partial TP, winners cover losers at a lower required win rate (~30% vs ~38%).
        # BE lock still active via check_breakeven_and_partials().
        return
        pos = self.active_position
        if not pos or pos.get("_partial_taken", False):
            return

        partial_take_r = float(pos.get("partial_take_r") or 0.0)
        partial_take_pct = float(pos.get("partial_take_pct") or 0.0)
        if partial_take_r <= 0.0 or partial_take_pct <= 0.0:
            return

        entry = float(pos.get("entry_price") or 0.0)
        size = float(pos.get("size") or 0.0)
        initial_stop = float(pos.get("initial_stop_loss") or 0.0)
        risk_dist = float(pos.get("initial_risk_dist") or abs(entry - initial_stop))
        if entry <= 0.0 or size <= 0.0 or risk_dist <= 0.0:
            return

        side = pos.get("side", "buy")
        favorable_move = current_price - entry if side == "buy" else entry - current_price
        trigger = partial_take_r * risk_dist
        if favorable_move < trigger:
            return

        partial_size = size * min(max(partial_take_pct, 0.0), 0.95)
        remaining_size = size - partial_size
        if partial_size <= 0.0 or remaining_size <= 0.0:
            return

        partial_pnl = self._estimate_partial_pnl(pos, current_price, partial_size)
        logger.info(
            f"[Executor] PARTIAL TP trigger hit: move={favorable_move:.2f} "
            f">= {partial_take_r:.2f}R ({trigger:.2f}). Closing {partial_take_pct:.0%}."
        )

        if self.dry_run:
            pos["size"] = remaining_size
            self._scale_entry_fees_for_partial(pos, size, remaining_size)
            pos["_partial_taken"] = True
            pos["realized_partial_pnl"] = float(pos.get("realized_partial_pnl") or 0.0) + partial_pnl
            self._log_partial_take(pos.get("trade_doc_id"), partial_size, current_price, partial_pnl, side)
            if not pos.get("_be_locked", False):
                await self.move_sl_to_breakeven(pos["symbol"], entry)
                pos["_be_locked"] = True
            return

        if not self.is_futures:
            logger.warning("[Executor] Partial TP skipped: live partial resizing is only enabled for futures.")
            return

        close_side = "sell" if side == "buy" else "buy"
        symbol = pos["symbol"]
        fmt_size = float(self.exchange.amount_to_precision(symbol, size))
        fmt_partial = float(self.exchange.amount_to_precision(symbol, partial_size))
        # Use the exchange-rounded close size to compute the residual. Computing
        # fmt_remaining from raw floats can leave dust: 0.049 - fmt(40%) 0.019
        # is 0.030, while fmt(raw 0.0294) can become 0.029 on Binance.
        fmt_remaining = float(self.exchange.amount_to_precision(symbol, max(0.0, fmt_size - fmt_partial)))
        if fmt_partial <= 0.0 or fmt_remaining <= 0.0:
            return

        try:
            await self.exchange.create_market_order(
                symbol,
                close_side,
                fmt_partial,
                params={"reduceOnly": True},
            )
            pos["size"] = fmt_remaining
            self._scale_entry_fees_for_partial(pos, size, fmt_remaining)
            pos["_partial_taken"] = True
            pos["realized_partial_pnl"] = float(pos.get("realized_partial_pnl") or 0.0) + partial_pnl
            self._log_partial_take(pos.get("trade_doc_id"), fmt_partial, current_price, partial_pnl, side)

            # P10 FIX: After partial TP, the price may have already moved past the BE+fees level,
            # causing "Order would immediately trigger" on the replacement SL. If the BE SL is
            # already breached, keep the original initial_stop_loss instead of emergency-flattening.
            initial_sl = float(pos.get("initial_stop_loss") or 0.0)
            if not pos.get("_be_locked", False):
                desired_stop_loss = entry
            else:
                be_candidate = float(pos.get("stop_loss") or entry)
                # For LONG: SL is a sell stop — triggered if price drops BELOW it.
                # For SHORT: SL is a buy stop — triggered if price rises ABOVE it.
                be_breached = (
                    (side == "buy" and current_price <= be_candidate) or
                    (side == "sell" and current_price >= be_candidate)
                )
                if be_breached and initial_sl > 0:
                    logger.warning(
                        f"[Executor] BE+fees SL {be_candidate:.2f} already breached "
                        f"(current price={current_price:.2f}). "
                        f"Using initial SL {initial_sl:.2f} instead."
                    )
                    desired_stop_loss = initial_sl
                else:
                    desired_stop_loss = be_candidate
            restored = await self._restore_reduced_exit_orders(pos, fmt_remaining, desired_stop_loss)

            if restored:
                pos["_be_locked"] = desired_stop_loss == entry
                logger.info(
                    f"[Executor] Partial TP complete. Remaining size={pos['size']} "
                    "with resized SL/TP protection."
                )
            else:
                logger.error(
                    "[Executor] Partial TP executed but replacement protection failed. "
                    "Flattening remaining size to avoid unmanaged bleed."
                )
                if self.notifier:
                    await self.notifier.send_error_alert(
                        f"Partial TP executed for {symbol}, but resized SL/TP placement failed. "
                        "Flattening remaining position."
                    )
                pos_snapshot = dict(pos)
                pnl = await self.emergency_flatten("Partial TP protection rebuild failed")
                self._pending_forced_exit = {
                    "pnl": float(pnl if pnl is not None else 0.0),
                    "regime": pos_snapshot.get("regime", "NEUTRAL"),
                    "position": pos_snapshot,
                    "reason": "partial_protection_rebuild_failed",
                }
        except Exception as e:
            logger.error(f"[Executor] Partial TP failed: {e}", exc_info=True)
            if self.notifier:
                await self.notifier.send_error_alert(f"Partial TP failed for {symbol}: {e}")

    async def check_breakeven_and_partials(self, current_price: float, atr: float, metrics: dict = None) -> None:
        """Check if breakeven stop should be locked, based on be_lock_trigger threshold.
        Partial TP is DISABLED — trades run to full TP/SL. Only BE lock is active."""
        if not self.active_position:
            return
        pos = self.active_position
        await self._maybe_take_partial_profit(current_price)
        if not self.active_position:
            return
        pos = self.active_position
        be_lock_trigger = pos.get("be_lock_trigger", 1.0)
        atr_at_entry = pos.get("atr_at_entry", 0.0)
        # P1 FIX: Add ATR minimum guard. Without it, a tiny atr_at_entry (quiet market)
        # means be_lock_trigger×atr_at_entry is a micro-pip amount — breakeven fires
        # on noise, immediately cutting the trade. Require at least 0.5×ATR of
        # absolute movement before considering breakeven.
        MIN_ATR_FRACTION = 0.5
        if atr_at_entry < atr * MIN_ATR_FRACTION:
            logger.debug(
                f"[Breakeven] Skipped — atr_at_entry={atr_at_entry:.2f} < {MIN_ATR_FRACTION}×ATR={atr*MIN_ATR_FRACTION:.2f}. Market too quiet."
            )
            return
        if be_lock_trigger <= 0.0 or atr_at_entry <= 0.0:
            return
        entry_price = pos["entry_price"]
        side = pos["side"]
        
        # C-3 FIX: Check opposing CVD divergence — move SL to breakeven if flow flips
        if metrics:
            cvd = metrics.get("cvd_divergence")
            if cvd and cvd.get("strength", 0) > 0.40:
                cvd_type = cvd.get("type", "")
                opp = (
                    (side == "buy"  and cvd_type in ("EXHAUSTION_SELL", "CONTINUATION_SELL")) or
                    (side == "sell" and cvd_type in ("EXHAUSTION_BUY",  "CONTINUATION_BUY"))
                )
                if opp and not pos.get("_be_locked", False):
                    logger.warning(
                        f"[Executor] Opposing CVD divergence ({cvd_type}, strength={cvd.get('strength', 0):.2f}). "
                        "Moving SL to BE."
                    )
                    await self.move_sl_to_breakeven(pos["symbol"], entry_price)
                    pos["_be_locked"] = True

        profit_target = be_lock_trigger * atr_at_entry
        regime = pos.get("regime", "NEUTRAL")
        if regime == "RANGE" and metrics:
            z_ret = metrics.get("zScore_ret", 0.0)
            if side == "buy" and z_ret > 0:
                profit_target *= 0.70
                logger.info(f"[Executor] RANGE dynamic BE: z_ret={z_ret:.3f} > 0 (reversal). Accelerating BE to {profit_target:.2f}")
            elif side == "sell" and z_ret < 0:
                profit_target *= 0.70
                logger.info(f"[Executor] RANGE dynamic BE: z_ret={z_ret:.3f} < 0 (reversal). Accelerating BE to {profit_target:.2f}")

        if side == "buy":
            unrealized_pnl = current_price - entry_price
        else:
            unrealized_pnl = entry_price - current_price

        if unrealized_pnl >= profit_target:
            if pos.get("_be_locked", False):
                return
            logger.info(
                f"[Executor] Breakeven threshold reached: profit={unrealized_pnl:.2f} "
                f">= trigger={profit_target:.2f} ({be_lock_trigger}×ATR). Moving SL to breakeven."
            )
            await self.move_sl_to_breakeven(pos["symbol"], entry_price)
            pos["_be_locked"] = True

    async def check_trailing_stop(self, current_price: float, atr: float) -> bool:
        """TREND trailing stop: activate after 2R profit, trail at 0.75*ATR behind running high/low."""
        if not self.active_position:
            return False
        pos = self.active_position
        regime = pos.get("regime", "NEUTRAL")
        if regime != "TREND":
            return False

        atr_at_entry = pos.get("atr_at_entry", 0.0)
        if atr_at_entry <= 0:
            return False

        entry_price = pos["entry_price"]
        side = pos["side"]
        risk_dist = abs(entry_price - pos.get("stop_loss", entry_price))

        activation_2r = 2.0 * risk_dist
        if side == "buy":
            unrealized_pnl = current_price - entry_price
        else:
            unrealized_pnl = entry_price - current_price

        if unrealized_pnl < activation_2r:
            pos["_trailing_active"] = False
            return False

        if not pos.get("_trailing_active", False):
            logger.info(f"[Executor] TREND trailing stop ACTIVATED at profit={unrealized_pnl:.2f} >= 2R={activation_2r:.2f}")
            pos["_trailing_active"] = True
            pos["_trailing_running_high"] = current_price if side == "buy" else current_price
            pos["_trailing_running_low"] = current_price if side == "sell" else current_price

        trailing_atr = 0.75 * atr
        trailing_stop = None
        if side == "buy":
            new_high = max(pos.get("_trailing_running_high", current_price), current_price)
            trailing_stop = new_high - trailing_atr
            pos["_trailing_running_high"] = new_high
            if trailing_stop <= (pos.get("stop_loss", 0) or 0):
                return False
        else:
            new_low = min(pos.get("_trailing_running_low", current_price), current_price)
            trailing_stop = new_low + trailing_atr
            pos["_trailing_running_low"] = new_low
            if trailing_stop >= (pos.get("stop_loss", float('inf')) or float('inf')):
                return False

        old_sl = pos.get("stop_loss", entry_price)

        if self.dry_run:
            pos["stop_loss"] = trailing_stop
            logger.info(f"[Executor] DRY-RUN: Trailing SL {old_sl:.2f} -> {trailing_stop:.2f}")
            return True

        sl_order_id = pos.get("sl_order_id")
        if not sl_order_id:
            logger.warning("[Executor] Trailing stop: no sl_order_id to cancel/replace")
            return False

        sl_side = "sell" if side == "buy" else "buy"
        try:
            await self.exchange.cancel_order(sl_order_id, pos["symbol"])
            logger.info(f"[Executor] Cancelled old SL order {sl_order_id}")
        except Exception as cancel_err:
            logger.error(f"[Executor] Trailing stop: cancel failed ({cancel_err}). Aborting replacement to avoid duplicate stops.")
            return False

        atr_for_sl = atr
        atr_multiplier = 0.02
        sl_limit_price = float(self.exchange.price_to_precision(
            pos["symbol"],
            trailing_stop + (atr_for_sl * atr_multiplier) if side == "buy" else trailing_stop - (atr_for_sl * atr_multiplier)
        ))
        try:
            new_sl_order = await self.exchange.create_order(
                symbol=pos["symbol"],
                type="STOP",
                side=sl_side,
                amount=pos["size"],
                price=sl_limit_price,
                params={
                    "stopPrice": float(self.exchange.price_to_precision(pos["symbol"], trailing_stop)),
                    "reduceOnly": True,
                },
            )
            pos["stop_loss"] = trailing_stop
            pos["sl_order_id"] = new_sl_order.get("id")
            logger.info(f"[Executor] Trailing SL placed: {new_sl_order.get('id')} at {trailing_stop:.2f}")
            return True
        except Exception as replace_err:
            logger.error(f"[Executor] Trailing SL placement failed ({replace_err}). Restoring old SL at {old_sl:.2f} to avoid naked position.")
            old_sl_limit = float(self.exchange.price_to_precision(
                pos["symbol"],
                old_sl + (atr_for_sl * atr_multiplier) if side == "buy" else old_sl - (atr_for_sl * atr_multiplier)
            ))
            try:
                restore_order = await self.exchange.create_order(
                    symbol=pos["symbol"],
                    type="STOP",
                    side=sl_side,
                    amount=pos["size"],
                    price=old_sl_limit,
                    params={
                        "stopPrice": float(self.exchange.price_to_precision(pos["symbol"], old_sl)),
                        "reduceOnly": True,
                    },
                )
                pos["sl_order_id"] = restore_order.get("id")
                logger.info(f"[Executor] Old SL restored: {restore_order.get('id')} at {old_sl:.2f}")
            except Exception as restore_err:
                logger.critical(f"[Executor] CRITICAL: Failed to restore old SL ({restore_err}). Emergency flattening to avoid naked position.")
                try:
                    flatten_side = "sell" if side == "buy" else "buy"
                    await self.exchange.create_market_order(
                        pos["symbol"], flatten_side, pos["size"],
                        params={"reduceOnly": True},
                    )
                    logger.info("[Executor] Emergency flatten after SL restore failure successful.")
                except Exception as flatten_err:
                    logger.critical(f"[Executor] Emergency flatten also FAILED ({flatten_err}). MANUAL INTERVENTION REQUIRED.")
                    self._flatten_failed = True
                if self.active_position:
                    self.active_position = None
                self.pending_order = None
            return False

    async def check_time_exit(self, current_price: float) -> tuple:
        """Close positions that exceed their regime max-hold window."""
        if not self.active_position:
            return False, 0.0

        pos = self.active_position
        time_exit_sec = float(pos.get("time_exit_sec") or 0.0)
        entry_ts = float(pos.get("entry_ts") or 0.0)
        if time_exit_sec <= 0.0 or entry_ts <= 0.0:
            return False, 0.0

        age = time.time() - entry_ts
        if age < time_exit_sec:
            return False, 0.0

        side = pos.get("side", "buy")
        size = float(pos.get("size") or 0.0)
        entry = float(pos.get("entry_price") or current_price)
        if size <= 0.0:
            logger.warning("[Executor] Time exit found zero-size position. Clearing stale state.")
            self.active_position = None
            self.pending_order = None
            return False, 0.0

        raw_pnl = (current_price - entry) * size if side == "buy" else (entry - current_price) * size
        est_pnl = raw_pnl - (entry + current_price) * size * self.TAKER_FEE
        est_pnl += float(pos.get("realized_partial_pnl") or 0.0)
        
        # PHASE 4: Enforce strict time exit hard cap explicitly from the position parameters
        is_volatile = pos.get("regime") == "VOLATILE"
        hard_time_exit_sec = pos.get("time_exit_hard_cap_s") or (time_exit_sec * (1.0 if is_volatile else 2.0))
        
        risk_dist = abs(float(pos.get("initial_risk_dist") or abs(entry - float(pos.get("stop_loss") or entry))))
        fee_slippage_buffer = (entry + current_price) * size * self.TAKER_FEE * 2.0
        min_time_exit_profit = max(0.0, risk_dist * size * 0.10, fee_slippage_buffer)
        if est_pnl < min_time_exit_profit and age < hard_time_exit_sec:
            if not pos.get("_time_exit_deferred_logged"):
                logger.info(
                    f"[Executor] Time exit deferred: age={age:.0f}s >= {time_exit_sec:.0f}s "
                    f"but estimated net PnL=${est_pnl:.2f} < min ${min_time_exit_profit:.2f}. "
                    f"Waiting for SL/TP or hard max {hard_time_exit_sec:.0f}s."
                )
                pos["_time_exit_deferred_logged"] = True
            return False, 0.0

        max_fee_drift_exit_sec = time_exit_sec * (1.0 if is_volatile else 4.0)
        max_tolerable_time_loss = -(risk_dist * size * 0.75)
        if (
            not is_volatile
            and est_pnl < min_time_exit_profit
            and est_pnl > max_tolerable_time_loss
            and age < max_fee_drift_exit_sec
        ):
            if not pos.get("_hard_time_exit_deferred_logged"):
                logger.info(
                    f"[Executor] Hard time exit deferred: age={age:.0f}s >= "
                    f"{hard_time_exit_sec:.0f}s but estimated net PnL=${est_pnl:.2f} "
                    f"is not below loss-cut ${max_tolerable_time_loss:.2f}. "
                    f"Keeping SL/TP protection until profit threshold or max "
                    f"{max_fee_drift_exit_sec:.0f}s."
                )
                pos["_hard_time_exit_deferred_logged"] = True
            return False, 0.0

        logger.warning(
            f"[Executor] TIME EXIT: age={age:.0f}s >= {time_exit_sec:.0f}s "
            f"for {pos.get('symbol')} | estimated PnL=${est_pnl:.2f}"
        )

        if self.dry_run:
            self._update_trade_exit(pos.get("trade_doc_id"), current_price, est_pnl)
            self.active_position = None
            self.pending_order = None
            return True, est_pnl

        self._last_panic_pnl = est_pnl
        realized_pnl = await self.emergency_flatten("Regime time exit")
        return True, float(realized_pnl if realized_pnl is not None else getattr(self, "_last_panic_pnl", est_pnl))

    async def check_position_exit(self, current_price: float,
                                   candle_high: float = None,
                                   candle_low: float = None) -> tuple:
        """
        Check SL/TP for position exit.

        DRY-RUN: Simulates SL/TP hits from candle high/low for realistic backtesting.
        LIVE MODE: Polls exchange fetch_positions() to detect real fills by the
                   exchange's STOP_MARKET / TAKE_PROFIT_MARKET orders.

        CRIT-1 FIX: Previously both modes ran the same simulation logic. In live mode
        this caused race conditions where internal state was cleared while the exchange
        still had open protective orders, leading to orphaned cancel calls and missed PnL.

        C6 FIX: Entire body is now protected by _position_lock (Semaphore(1)).
        This prevents the heartbeat poll and main loop from simultaneously clearing
        active_position, which caused duplicate Firestore writes and double alerts.

        Returns (exited: bool, pnl: float).
        """
        # C6 FIX: Acquire lock before reading active_position.
        # Semaphore(1) is reentrant — if we already hold it (e.g. check_position_exit
        # → _check_live_position_exit), nested acquisition does not deadlock.
        async with self._position_lock:
            pos = self.active_position
            if pos is None:
                return False, 0.0

            if not self.dry_run:
                return await self._check_live_position_exit(current_price)

            # ── DRY-RUN simulation ────────────────────────────────────────────
            side = pos["side"]
            sl   = pos["stop_loss"]
            tp   = pos["take_profit"]

            # PHASE-0.3: Use exchange-specific fees set in __init__
            TAKER_FEE = self.TAKER_FEE
            MAKER_FEE = self.MAKER_FEE

            size = pos.get("size") or pos.get("qty") or 0.0
            if size <= 0:
                logger.warning("[Executor] Active position has 0 size. Clearing stale state.")
                self.active_position = None
                return False, 0.0

            notional = size * pos["entry_price"]
            entry_fee = notional * TAKER_FEE

            # Use candle high/low for realistic SL/TP simulation if available
            check_high = candle_high if candle_high is not None else current_price
            check_low  = candle_low  if candle_low  is not None else current_price

            async def finalize_exit(exit_type: str, exit_price: float):
                nonlocal notional, entry_fee, side
                # C6 FIX: Set active_position = None FIRST before any await.
                # This prevents a second concurrent call (heartbeat or loop) from
                # seeing a stale non-None active_position while this function is
                # still awaiting send_close_alert.
                self.active_position = None
                self.pending_order = None
                exit_notional = size * exit_price
                exit_fee = exit_notional * (MAKER_FEE if exit_type == "TP" else TAKER_FEE)

                raw_pnl = (exit_price - pos["entry_price"]) * size if side == "buy" else (pos["entry_price"] - exit_price) * size
                net_pnl = raw_pnl - (entry_fee + exit_fee)
                net_pnl += float(pos.get("realized_partial_pnl") or 0.0)
                logger.info(f"[Executor] {exit_type} HIT{' (SHORT)' if side == 'sell' else ''}. Net PnL=${net_pnl:.2f} (Fees: ${entry_fee+exit_fee:.2f})")

                if hasattr(self, "notifier") and self.notifier:
                    await self.notifier.send_close_alert(
                        symbol=pos["symbol"], side=side, price=exit_price, type=exit_type, pnl=net_pnl, is_dry=self.dry_run
                    )
                self._update_trade_exit(pos.get("trade_doc_id"), exit_price, net_pnl)
                return True, net_pnl

            if side == "buy":
                if check_low <= sl:
                    return await finalize_exit("SL", sl)
                if check_high >= tp:
                    return await finalize_exit("TP", tp)
            else:
                if check_high >= sl:
                    return await finalize_exit("SL", sl)
                if check_low <= tp:
                    return await finalize_exit("TP", tp)

            return False, 0.0

    async def _check_live_position_exit(self, current_price: float) -> tuple:
        """
        LIVE MODE: Poll exchange to detect if position was closed by SL/TP orders.

        P0-1 GHOST-POSITION FIX:
        Binance USDM Futures OMITS zero-quantity positions from fetch_positions entirely.
        The old code searched for a matching symbol with qty < 0.0001 — since Binance
        never returns that entry at all when flat, the position was never detected as closed.

        Correct approach: build a set of symbols that have NON-ZERO qty (open_syms).
        If our symbol is ABSENT from open_syms, the position is flat on the exchange.
        Then fetch the actual fill price + realized PnL from trade history.

        C6 FIX: Body NOT wrapped in _position_lock. The lock is held by the caller
        (check_position_exit → _check_live_position_exit). `_position_lock` is a
        Semaphore(1) — Python asyncio.Semaphore is NOT reentrant. A nested
        acquisition here would deadlock. The outer lock in check_position_exit
        is the only acquisition needed for the entire exit check path.
        """
        pos = self.active_position
        if pos is None:
            return False, 0.0

        symbol = pos.get("symbol", "")
        now = time.time()
        if now < self._live_exit_backoff_until:
            return False, 0.0
        if self._live_exit_last_poll_ts and (now - self._live_exit_last_poll_ts) < self._live_exit_poll_interval_s:
            return False, 0.0
        self._live_exit_last_poll_ts = now
        logger.debug(f"[LiveExit] Polling exchange for {symbol}…")

        try:
            # Fetch ALL positions — Binance only returns non-flat ones
            all_positions = await self.exchange.fetch_positions()

            # Build the set of symbols that are genuinely open (qty > noise floor)
            open_syms = {
                p.get("symbol")
                for p in all_positions
                if abs(float(p.get("contracts", 0) or 0)) > 0.0001
            }

            if symbol not in open_syms:
                # ── Position is FLAT on the exchange ────────────────────────
                # The SL or TP order was filled by Binance; bot state is stale.
                entry = pos["entry_price"]
                size  = pos["size"]
                side  = pos["side"]
                close_side = "sell" if side == "buy" else "buy"

                # Fetch actual fill price + exchange-reported realized PnL
                fill_price = current_price  # fallback
                actual_pnl = None
                closing_summary = None
                try:
                    recent_trades = await self.exchange.fetch_my_trades(symbol, limit=50)
                    closing_summary = self._aggregate_closing_trades(recent_trades, close_side, pos)
                    if closing_summary:
                        fill_price = float(closing_summary["fill_price"])
                        actual_pnl = float(closing_summary["gross_pnl"])
                        fill_count = int(closing_summary.get("trade_count") or 1)
                        amount = float(closing_summary.get("amount") or 0.0)
                        logger.info(
                            f"[LiveExit] Exchange close aggregated: fills={fill_count} "
                            f"amount={amount:.8f} fill={fill_price:.2f} "
                            f"grossPnl=${actual_pnl:.2f}"
                        )
                except Exception as e:
                    logger.warning(f"[LiveExit] fill-price fetch failed: {e}")

                # Use exchange PnL if available, otherwise estimate from geometry
                if actual_pnl is not None:
                    net_pnl, fees = self._net_exchange_realized_pnl(
                        actual_pnl,
                        pos,
                        fill_price,
                        closing_fee=(
                            float(closing_summary.get("close_fee") or 0.0)
                            if closing_summary
                            else None
                        ),
                    )
                    logger.info(
                        f"[LiveExit] Fee-adjusted PnL: gross=${actual_pnl:.2f} "
                        f"fees=${fees:.2f} net=${net_pnl:.2f}"
                    )
                else:
                    raw_pnl = ((fill_price - entry) * size if side == "buy"
                               else (entry - fill_price) * size)
                    fees = (entry + fill_price) * size * self.TAKER_FEE
                    net_pnl = raw_pnl - fees
                net_pnl += float(pos.get("realized_partial_pnl") or 0.0)

                exit_type = self._classify_live_exit_type(pos, fill_price)
                logger.info(
                    f"[LiveExit] Position flat on exchange — type={exit_type} "
                    f"pnl=${net_pnl:.2f} fill={fill_price:.2f}"
                )
                if self.notifier:
                    await self.notifier.send_close_alert(
                        symbol=symbol, side=side, price=fill_price,
                        type=exit_type, pnl=net_pnl, is_dry=False
                    )
                self._update_trade_exit(pos.get("trade_doc_id"), fill_price, net_pnl)
                self.active_position = None
                self.pending_order = None
                return True, net_pnl

            # Symbol still present in open_syms → position still live
            self._live_exit_backoff_s = 30.0
            self._live_exit_backoff_until = 0.0
            return False, 0.0

        except Exception as e:
            msg = str(e)
            if "429" in msg or "Too Many Requests" in msg or "-1003" in msg:
                self._live_exit_backoff_until = time.time() + self._live_exit_backoff_s
                self._live_exit_backoff_s = min(self._live_exit_backoff_s * 2, 900.0)
            now = time.time()
            if now - self._live_exit_last_error_log >= 60:
                logger.warning(f"[LiveExit] poll error: {e}")
                self._live_exit_last_error_log = now
            return False, 0.0



    async def cancel_opposing_orders(self, filled_side: str = "sl"):
        """
        Cancel the opposing order after one side fills.
        In LIVE mode: if SL fills, cancel TP order (and vice versa).
        Prevents naked re-entries from orphaned orders.
        """
        pos = self.active_position
        if pos is None:
            return

        cancel_id = pos.get("tp_order_id") if filled_side == "sl" else pos.get("sl_order_id")
        symbol = pos.get("symbol", "")

        if cancel_id:
            try:
                await self.exchange.cancel_order(cancel_id, symbol)
                label = "TP" if filled_side == "sl" else "SL"
                logger.info(f"[Executor] Cancelled opposing {label} order {cancel_id} ✓")
            except Exception as e:
                # -2011 "Unknown order sent" means Binance already cancelled it
                # (closePosition=True orders are auto-cleaned when position closes).
                err_str = str(e).lower()
                already_gone = (
                    "-2011" in err_str
                    or "unknown order" in err_str
                    or "not found" in err_str
                    or "not_found" in err_str
                )
                if already_gone:
                    label = "TP" if filled_side == "sl" else "SL"
                    logger.info(f"[Executor] Opposing {label} order {cancel_id} already gone (Binance cleaned it) ✓")
                else:
                    logger.warning(f"[Executor] Failed to cancel opposing order {cancel_id}: {e}")

    def is_system_locked(self) -> bool:
        """Check if the system is currently under a panic-mode lock."""
        return time.time() < self.lock_expiry

    async def engage_panic_mode(self, reason: str, lock_seconds: int = 300):
        """
        Engages the killswitch: attempts emergency flatten then locks the system.
        """
        logger.warning(f"[PanicMode] ENGAGED! Reason: {reason}. Locking system for {lock_seconds}s.")
        self.lock_expiry = time.time() + lock_seconds
        self.last_panic_reason = reason

        if self.active_position and not self.dry_run:
            logger.warning(f"[PanicMode] Attempting emergency flatten before locking.")
            try:
                await self.emergency_flatten(f"Panic mode triggered: {reason}")
                logger.info("[PanicMode] Emergency flatten succeeded.")
            except Exception as flatten_err:
                logger.error(
                    f"[PanicMode] Flatten attempt failed: {flatten_err}. "
                    "Falling through to resting STOP_MARKET order."
                )

        if self.notifier:
            await self.notifier.send_message(f"🚨 PANIC MODE ENGAGED!\nReason: {reason}\nSystem locked for {lock_seconds}s.", critical=True)

    async def emergency_flatten(self, reason: str):
        """Immediately closes the current position with a Market Order."""
        if not self.active_position:
            return

        pos = self.active_position
        ex_symbol = pos["symbol"]
        side = pos["side"]
        size = pos["size"]
        close_side = "sell" if side == "buy" else "buy"

        logger.warning(f"[Executor] EMERGENCY FLATTEN triggered ({reason}) for {size} {ex_symbol}")

        try:
            if not self.dry_run:
                # 1. Cancel all open orders for this symbol first
                try:
                    await self.exchange.cancel_all_orders(ex_symbol)
                except Exception:
                    pass

                # 2. Market close
                await self.exchange.create_market_order(ex_symbol, close_side, size, params={"reduceOnly": True})

            logger.info(f"[Executor] Flattened {ex_symbol} ✅")

            # BUG-2 + HIGH-1 FIX: Fetch actual fill price from trade history.
            # Old code: _last_price never set → fill_price always = entry → PnL always $0.
            # Every panic exit was recorded as flat, bypassing the daily loss limit.
            entry = pos.get("entry_price", 0.0)
            size  = pos.get("size", 0.0)
            side  = pos.get("side", "buy")
            fill_price = entry  # fallback
            est_pnl    = 0.0
            if not self.dry_run:
                try:
                    recent = await self.exchange.fetch_my_trades(ex_symbol, limit=50)
                    closing_summary = self._aggregate_closing_trades(recent, close_side, pos)
                    if closing_summary:
                        fill_price = float(closing_summary["fill_price"])
                        gross_pnl = float(closing_summary["gross_pnl"])
                        est_pnl, fees = self._net_exchange_realized_pnl(
                            gross_pnl,
                            pos,
                            fill_price,
                            closing_fee=float(closing_summary.get("close_fee") or 0.0),
                        )
                        logger.info(
                            f"[Flatten] Exchange PnL: gross=${gross_pnl:.2f} "
                            f"fees=${fees:.2f} net=${est_pnl:.2f} "
                            f"fill={fill_price:.2f} fills={int(closing_summary.get('trade_count') or 1)}"
                        )
                    else:
                        # Estimate from entry vs current candle close
                        raw = (fill_price - entry) * size if side == "buy" else (entry - fill_price) * size
                        est_pnl = raw - (entry + fill_price) * size * self.TAKER_FEE
                except Exception as fe:
                    logger.warning(f"[Flatten] Could not fetch fill: {fe}")
            est_pnl += float(pos.get("realized_partial_pnl") or 0.0)
            # HIGH-1 FIX: pass real fill_price (not 0.0) to Firestore
            self._last_panic_pnl = est_pnl  # BUG-3: expose for main.py daily_pnl update
            self._update_trade_exit(pos.get("trade_doc_id"), fill_price, est_pnl)
            self.active_position = None
            return est_pnl
        except Exception as e:
            # 3.4 FIX: Critical failure requires immediate human action.
            # Fire Telegram and log at CRITICAL level regardless of any other state.
            msg = (
                f"🚨 CRITICAL: FAILED TO FLATTEN POSITION\n"
                f"Symbol: {ex_symbol} | Side: {side.upper()} | Size: {size}\n"
                f"Reason: {reason}\n"
                f"Error: {str(e)}\n"
                f"ACTION REQUIRED: Log into exchange immediately and close this position manually."
            )
            logger.critical(msg)
            if self.notifier:
                try:
                    await self.notifier.send_message(msg)
                except Exception as notify_err:
                    logger.error(f"[Executor] Also failed to send Telegram alert: {notify_err}")
            # P0-3 FIX: Use a dedicated boolean flag, NOT a sentinel dict.
            # The 30s heartbeat poll calls _check_live_position_exit which sets
            # active_position = None if the symbol is gone — silently wiping the
            # sentinel dict and allowing the bot to resume trading unprotected.
            # A separate boolean survives the poll clearing active_position.
            self._flatten_failed = True
            self.active_position = None  # Clear position — halt is enforced via _flatten_failed flag
            return None

    async def attempt_tp_requeue(self) -> bool:
        """
        H4 FIX: Retry TP placement for positions that entered without a TP attached.

        Called by main.py on every analysis cycle when active_position has
        requeue_tp_attempts > 0. Retries up to MAX_REQUEUE_ATTEMPTS times.
        Returns True if TP was successfully placed, False if max attempts exhausted.
        """
        pos = self.active_position
        if pos is None:
            return False

        if not pos.get("requeue_tp_attempts", 0):
            return False  # No pending TP requeue

        attempts = pos["requeue_tp_attempts"]
        if attempts > MAX_REQUEUE_ATTEMPTS:
            logger.warning(
                f"[Executor] TP requeue attempts ({attempts}) >= MAX_REQUEUE_ATTEMPTS "
                f"({MAX_REQUEUE_ATTEMPTS}). Giving up on TP. Position has SL only."
            )
            pos.pop("requeue_tp_attempts", None)
            pos.pop("requeue_tp_side", None)
            pos.pop("requeue_tp_size", None)
            pos.pop("requeue_tp_price", None)
            pos.pop("requeue_tp_symbol", None)
            return False

        symbol = pos.get("requeue_tp_symbol")
        side = pos.get("requeue_tp_side")
        size = pos.get("requeue_tp_size")
        tp_price = pos.get("requeue_tp_price")

        if not all([symbol, side, size, tp_price]):
            logger.error("[Executor] TP requeue: missing position fields — clearing requeue state.")
            for k in ["requeue_tp_attempts", "requeue_tp_side", "requeue_tp_size", "requeue_tp_price", "requeue_tp_symbol"]:
                pos.pop(k, None)
            return False

        for attempt in range(3):
            try:
                tp_order = await self.exchange.create_order(
                    symbol=symbol,
                    type="TAKE_PROFIT_MARKET",
                    side=side,
                    amount=size,
                    params={
                        "stopPrice": tp_price,
                        "reduceOnly": True,   # P15 FIX: closePosition+amount undefined; use reduceOnly
                        "workingType": "MARK_PRICE",
                    },
                )
                pos["tp_order_id"] = tp_order.get("id")
                pos["bracket_status"] = "BRACKETED"
                pos["bracket_missing_leg"] = None
                pos["last_bracket_check_ts"] = time.time()
                for k in ["requeue_tp_attempts", "requeue_tp_side", "requeue_tp_size", "requeue_tp_price", "requeue_tp_symbol"]:
                    pos.pop(k, None)
                logger.info(f"[Executor] TP requeue SUCCESS — TP placed at {tp_price} (attempt {attempts}) ✓")
                return True
            except Exception as e:
                logger.warning(
                    f"[Executor] TP requeue attempt {attempts}/{MAX_REQUEUE_ATTEMPTS}, "
                    f"inner attempt {attempt+1}/3 failed: {e}"
                )
                if attempt < 2:
                    await asyncio.sleep(1.0)

        # All 3 inner attempts failed this cycle — increment and alert
        pos["requeue_tp_attempts"] = attempts + 1
        logger.warning(
            f"[Executor] TP requeue inner loop exhausted. "
            f"Attempt {attempts+1}/{MAX_REQUEUE_ATTEMPTS}. Will retry next cycle."
        )
        if pos["requeue_tp_attempts"] >= MAX_REQUEUE_ATTEMPTS:
            await self.notifier.send_error_alert(
                f"⚠️ TP placement FAILED after {MAX_REQUEUE_ATTEMPTS} requeue attempts. "
                f"Position is unprotected — SL active. Manual intervention required."
            )
        return False

